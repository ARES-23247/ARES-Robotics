package com.areslib.math.geometry

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.hypot
import com.areslib.math.wrapAngle

/**
 * Represents a 2D translational vector or point $(x, y)$ in Cartesian space.
 *
 * Core component for the Redux and Control architecture, primarily used in kinematics 
 * and state space representations for tracking spatial coordinates.
 *
 * Designed with value-semantics in mind. In high-frequency 50Hz/100Hz loops, allocations of this 
 * class should be minimized or managed by a memory pool / value class unboxing to guarantee zero-GC pauses.
 *
 * ### Physical Units & Coordinates:
 * - Position $(x, y)$: Meters ($m$)
 * - Positive X is typically forward, Positive Y is typically left (following standard CCW-positive robotics convention).
 *
 * @param x The X-coordinate displacement in meters ($m$).
 * @param y The Y-coordinate displacement in meters ($m$).
 */
data class Translation2d(val x: Double = 0.0, val y: Double = 0.0) {
    /**
     * Calculates the Euclidean norm (magnitude) of the translation vector.
     * $$ \|v\| = \sqrt{x^2 + y^2} $$
     * 
     * Guaranteed zero-GC allocation.
     * 
     * @return Vector magnitude in meters ($m$).
     */
    val norm: Double get() = hypot(x, y)

    operator fun plus(other: Translation2d): Translation2d = Translation2d(x + other.x, y + other.y)
    operator fun minus(other: Translation2d): Translation2d = Translation2d(x - other.x, y - other.y)
    operator fun times(scalar: Double): Translation2d = Translation2d(x * scalar, y * scalar)
    operator fun div(scalar: Double): Translation2d = Translation2d(x / scalar, y / scalar)
    operator fun unaryMinus(): Translation2d = Translation2d(-x, -y)

    /**
     * Rotates this translation vector around the origin by the given rotation angle.
     */
    fun rotateBy(rotation: Rotation2d): Translation2d {
        val cos = rotation.cos
        val sin = rotation.sin
        return Translation2d(x * cos - y * sin, x * sin + y * cos)
    }

    /** Calculates Euclidean distance to another translation point. */
    fun distanceTo(other: Translation2d): Double = hypot(other.x - x, other.y - y)

    /** Calculates squared Euclidean distance to another point (avoids square root). */
    fun distanceSquared(other: Translation2d): Double {
        val dx = other.x - x
        val dy = other.y - y
        return dx * dx + dy * dy
    }

    /** Dot product with another translation vector. */
    fun dot(other: Translation2d): Double = x * other.x + y * other.y

    /** Direction angle of this vector from the origin. */
    fun angle(): Rotation2d = Rotation2d(kotlin.math.atan2(y, x))

    /**
     * Normalizes this translation vector to a unit vector with norm 1.0.
     * Returns Translation2d(0.0, 0.0) if the norm is zero or non-finite.
     */
    fun normalize(): Translation2d {
        val magnitude = norm
        return if (magnitude.isFinite() && magnitude > 1e-15) {
            Translation2d(x / magnitude, y / magnitude)
        } else {
            Translation2d(0.0, 0.0)
        }
    }
}

/**
 * Represents a 2D rotational orientation.
 *
 * Implemented as a Kotlin `value class` to ensure zero-GC allocations on 50Hz/100Hz hot paths 
 * when directly manipulating angles, acting as a primitive at runtime.
 *
 * ### Physical Units & Coordinates:
 * - Angle: Radians ($rad$), mathematically wrapped to $[-\pi, \pi)$.
 * - **CCW-positive** convention: $0^\circ$ is +X, $90^\circ$ is +Y.
 *
 * @param rawRadians The raw rotation value in radians ($rad$).
 */
@JvmInline value class Rotation2d(val rawRadians: Double = 0.0) {
    /** 
     * The wrapped rotation value in radians ($rad$) bounded to $[-\pi, \pi)$. 
     * $$ \theta_{\text{wrapped}} = (\theta + \pi \pmod{2\pi}) - \pi $$
     */
    val radians: Double get() = wrapAngle(rawRadians)

    /** The rotation value in degrees ($^\circ$). */
    val degrees: Double get() = Math.toDegrees(radians)
    
    /** The cosine of the rotation angle. Zero-GC. */
    val cos: Double get() = cos(radians)
    
    /** The sine of the rotation angle. Zero-GC. */
    val sin: Double get() = sin(radians)

    operator fun plus(other: Rotation2d): Rotation2d = Rotation2d(radians + other.radians)
    operator fun minus(other: Rotation2d): Rotation2d = Rotation2d(radians - other.radians)
    operator fun times(scalar: Double): Rotation2d = Rotation2d(radians * scalar)
    operator fun unaryMinus(): Rotation2d = Rotation2d(-radians)

    fun rotateBy(other: Rotation2d): Rotation2d = this + other
    
    companion object {
        /**
         * Factory method to construct a Rotation2d from degrees.
         * 
         * @param degrees The rotation in degrees ($^\circ$).
         * @return A Rotation2d instance.
         */
        fun fromDegrees(degrees: Double): Rotation2d = Rotation2d(Math.toRadians(degrees))

        /**
         * Factory method to construct a Rotation2d from radians.
         */
        fun fromRadians(radians: Double): Rotation2d = Rotation2d(radians)
    }
}

/**
 * Represents a 2D rigid body transform or spatial pose $(x, y, \theta)$.
 *
 * Serves as the fundamental state representation for global robot odometry and path following.
 *
 * Designed with value-semantics in mind. For high-frequency 50Hz/100Hz loops, allocations should be 
 * tracked and minimized to maintain zero-GC overhead.
 *
 * ### Physical Units & Coordinates:
 * - Position $(x, y)$: Meters ($m$)
 * - Heading $(\theta)$: Radians ($rad$)
 * - **CCW-positive** heading convention: $0^\circ = +X$, $90^\circ = +Y$.
 *
 * @param x The X-coordinate displacement in meters ($m$).
 * @param y The Y-coordinate displacement in meters ($m$).
 * @param heading The rotational orientation of the pose.
 */
data class Pose2d(
    val x: Double = 0.0,
    val y: Double = 0.0,
    val heading: Rotation2d = Rotation2d()
) {
    /** Extracts the translational component $(x, y)$ of the pose. */
    val translation: Translation2d get() = Translation2d(x, y)

    /** Transforms this pose by a local delta displacement and delta heading. */
    fun transformBy(deltaTranslation: Translation2d, deltaHeading: Rotation2d): Pose2d {
        val rotatedDelta = deltaTranslation.rotateBy(heading)
        return Pose2d(x + rotatedDelta.x, y + rotatedDelta.y, heading + deltaHeading)
    }

    /** Calculates 2D translational distance to another pose. */
    fun distanceTo(other: Pose2d): Double = translation.distanceTo(other.translation)

    /**
     * Calculates the relative pose of this pose with respect to [other] as the reference origin frame.
     *
     * Expresses the displacement and relative orientation in the [other] body coordinate frame:
     * $$ \Delta \mathbf{t} = (\mathbf{t} - \mathbf{t}_{\text{other}}).\text{rotateBy}(-\text{other.heading}) $$
     * $$ \Delta \theta = \text{heading} - \text{other.heading} $$
     *
     * @param other The reference origin pose.
     * @return The relative pose in [other]'s coordinate frame.
     */
    fun relativeTo(other: Pose2d): Pose2d {
        val deltaTrans = Translation2d(x - other.x, y - other.y).rotateBy(-other.heading)
        return Pose2d(deltaTrans.x, deltaTrans.y, heading - other.heading)
    }
}

/**
 * Formats a Pose2d into a standard human-readable format: "(X.XX, Y.YY) DEGREES°".
 * 
 * Note: String allocation inherently triggers GC, so avoid calling in 50Hz/100Hz hot loops unless required for telemetry.
 * 
 * @receiver The [Pose2d] instance to format.
 * @return A formatted string representation.
 */
fun Pose2d.toFormattedString(): String =
    String.format("(%.2f, %.2f) %.1f°", x, y, Math.toDegrees(heading.radians))
