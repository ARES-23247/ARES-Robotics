package com.areslib.control.profile

import kotlin.math.sqrt

/**
 * Zero-Allocation 1D Kinematic Trapezoidal Motion Profile Generator.
 *
 * Computes deterministic position ($x$) and velocity ($v$) trajectory setpoints to transition a physical mechanism from an initial
 * state $(x_0, v_0)$ to a target goal state $(x_{goal}, v_{goal})$ while strictly respecting physical maximum cruise velocity ($v_{max}$)
 * and maximum acceleration ($a_{max}$) limits. An initially excessive speed brakes at the
 * acceleration limit until it re-enters the permitted velocity range; it is never clipped instantly.
 *
 * ### Kinematic Equations:
 * 1. **Acceleration Phase** ($t \le t_{accel}$):
 *    $$v(t) = v_0 + \text{dir} \cdot a_{max} \cdot t$$
 *    $$x(t) = x_0 + v_0 \cdot t + \frac{1}{2} \cdot \text{dir} \cdot a_{max} \cdot t^2$$
 * 2. **Constant Velocity Cruise Phase** ($t_{accel} < t \le t_{accel} + t_{cruise}$):
 *    $$v(t) = \text{dir} \cdot v_{max}$$
 *    $$x(t) = x_{accel} + v(t) \cdot (t - t_{accel})$$
 * 3. **Deceleration Phase** ($t_{accel} + t_{cruise} < t \le t_{total}$):
 *    $$v(t) = v_{cruise} - \text{dir} \cdot a_{max} \cdot (t - t_{accel} - t_{cruise})$$
 *    $$x(t) = x_{decel} + v_{cruise} \cdot (t') - \frac{1}{2} \cdot \text{dir} \cdot a_{max} \cdot (t')^2$$
 *
 * ### Physical Units & Properties:
 * - Position ($x$): Meters ($m$) or Radians ($rad$)
 * - Velocity ($v$): Meters per second ($m/s$) or Radians per second ($rad/s$)
 * - Acceleration ($a$): Meters per second squared ($m/s^2$) or Radians per second squared ($rad/s^2$)
 * - Timestep ($\Delta t$): Seconds ($s$)
 * - Memory Footprint: 100% Zero-GC allocation compliance during update cycles.
 *
 * @see State
 * @see Constraints
 */
class TrapezoidProfile {
    private val currentLocal = State()
    private val goalLocal = State()

    /**
     * Physical kinematic maximum velocity and acceleration limits bounding mechanism movement.
     *
     * @property maxVelocity Maximum allowable cruise velocity limit $v_{max}$ ($m/s$ or $rad/s$).
     * @property maxAcceleration Maximum allowable acceleration limit $a_{max}$ ($m/s^2$ or $rad/s^2$).
     */
    data class Constraints(
        var maxVelocity: Double = 0.0,
        var maxAcceleration: Double = 0.0
    )

    /**
     * Trajectory state representation at a discrete time instant $(x(t), v(t))$.
     *
     * @property position Mechanism position $x(t)$ in meters ($m$) or radians ($rad$).
     * @property velocity Mechanism velocity $v(t)$ in meters per second ($m/s$) or radians per second ($rad/s$).
     */
    data class State(
        var position: Double = 0.0,
        var velocity: Double = 0.0
    ) {
        /**
         * Copies values from another state into this instance without heap allocations.
         *
         * @param other Source [State] to copy from.
         */
        fun setTo(other: State) {
            this.position = other.position
            this.velocity = other.velocity
        }
    }

    /**
     * Computes the interpolated motion profile state after $\Delta t$ seconds, writing the result directly into [outState].
     *
     * @param dtSeconds Timestep duration in seconds ($\Delta t > 0$).
     * @param current Current mechanism state $(x_0, v_0)$.
     * @param goal Target mechanism state $(x_{goal}, v_{goal})$.
     * @param constraints Physical velocity ($v_{max}$) and acceleration ($a_{max}$) constraints [Constraints].
     * @param outState Pre-allocated [State] output container receiving computed position and velocity setpoints.
     */
    fun calculate(
        dtSeconds: Double,
        current: State,
        goal: State,
        constraints: Constraints,
        outState: State
    ) {
        currentLocal.setTo(current)
        goalLocal.setTo(goal)

        if (!dtSeconds.isFinite() || dtSeconds <= 0.0 ||
            !constraints.maxAcceleration.isFinite() || constraints.maxAcceleration <= 0.0 ||
            !constraints.maxVelocity.isFinite() || constraints.maxVelocity <= 0.0 ||
            !currentLocal.position.isFinite() || !currentLocal.velocity.isFinite() ||
            !goalLocal.position.isFinite() || !goalLocal.velocity.isFinite()
        ) {
            if (currentLocal.position.isFinite() && currentLocal.velocity.isFinite()) {
                outState.setTo(currentLocal)
            } else {
                outState.position = 0.0
                outState.velocity = 0.0
            }
            return
        }

        // Solve in a coordinate system where the goal is always in the positive direction.
        // This is the standard cutoff-distance formulation and supports arbitrary finite
        // initial and final velocities rather than assuming both are zero.
        val maxV = constraints.maxVelocity
        val maxA = constraints.maxAcceleration
        if (kotlin.math.abs(goalLocal.velocity) > maxV) {
            outState.setTo(currentLocal)
            return
        }

        // A lowered cruise limit cannot be met instantaneously. Integrate the initial
        // braking segment first, then solve the remaining profile from its endpoint.
        var stepSeconds = dtSeconds
        val initialSpeed = kotlin.math.abs(currentLocal.velocity)
        if (initialSpeed > maxV) {
            val brakingTime = (initialSpeed - maxV) / maxA
            val brakingStep = minOf(stepSeconds, brakingTime)
            val directionOfMotion = kotlin.math.sign(currentLocal.velocity)
            val brakingVelocity = if (stepSeconds >= brakingTime) directionOfMotion * maxV
                else currentLocal.velocity - directionOfMotion * maxA * brakingStep
            val brakingPosition = currentLocal.position +
                (currentLocal.velocity * 0.5 + brakingVelocity * 0.5) * brakingStep
            if (!brakingPosition.isFinite() || !brakingVelocity.isFinite()) {
                outState.setTo(currentLocal)
                return
            }
            currentLocal.position = brakingPosition
            currentLocal.velocity = brakingVelocity
            if (stepSeconds <= brakingTime) {
                outState.setTo(currentLocal)
                return
            }
            stepSeconds -= brakingTime
        }

        var direction = if (currentLocal.position > goalLocal.position) -1.0 else 1.0
        val invMaxA = 1.0 / maxA
        val invMaxV = 1.0 / maxV

        var currentPosition = currentLocal.position * direction
        var currentVelocity = currentLocal.velocity * direction
        var goalPosition = goalLocal.position * direction
        var goalVelocity = goalLocal.velocity * direction
        var cutoffBegin = currentVelocity * invMaxA
        var cutoffDistBegin = 0.5 * currentVelocity * cutoffBegin
        var cutoffEnd = goalVelocity * invMaxA
        var cutoffDistEnd = 0.5 * goalVelocity * cutoffEnd
        var fullTrapezoidDist = cutoffDistBegin + (goalPosition - currentPosition) + cutoffDistEnd
        if (!fullTrapezoidDist.isFinite() || fullTrapezoidDist < 0.0) {
            outState.setTo(currentLocal)
            return
        }

        var accelerationTime = maxV * invMaxA
        var fullSpeedDist = fullTrapezoidDist - accelerationTime * maxV
        if (fullSpeedDist < 0.0) {
            accelerationTime = sqrt(fullTrapezoidDist * invMaxA)
            fullSpeedDist = 0.0
        }

        // A positive boundary velocity above the monotonic profile's peak means the
        // mechanism cannot stop at the goal without first overshooting it. Reverse the
        // profile coordinate so the solution brakes, reverses, and returns continuously.
        if (cutoffBegin > accelerationTime || cutoffEnd > accelerationTime) {
            direction = -direction
            currentPosition = currentLocal.position * direction
            currentVelocity = currentLocal.velocity * direction
            goalPosition = goalLocal.position * direction
            goalVelocity = goalLocal.velocity * direction
            cutoffBegin = currentVelocity * invMaxA
            cutoffDistBegin = 0.5 * currentVelocity * cutoffBegin
            cutoffEnd = goalVelocity * invMaxA
            cutoffDistEnd = 0.5 * goalVelocity * cutoffEnd
            fullTrapezoidDist = cutoffDistBegin + (goalPosition - currentPosition) + cutoffDistEnd
            if (!fullTrapezoidDist.isFinite() || fullTrapezoidDist < 0.0) {
                outState.setTo(currentLocal)
                return
            }
            accelerationTime = maxV * invMaxA
            fullSpeedDist = fullTrapezoidDist - accelerationTime * maxV
            if (fullSpeedDist < 0.0) {
                accelerationTime = sqrt(fullTrapezoidDist * invMaxA)
                fullSpeedDist = 0.0
            }
        }

        val endAccel = accelerationTime - cutoffBegin
        val endFullSpeed = endAccel + fullSpeedDist * invMaxV
        val endDecel = endFullSpeed + accelerationTime - cutoffEnd

        val newPosition: Double
        val newVelocity: Double
        when {
            stepSeconds < endAccel -> {
                newVelocity = currentVelocity + stepSeconds * maxA
                newPosition = currentPosition + (currentVelocity + stepSeconds * maxA * 0.5) * stepSeconds
            }
            stepSeconds < endFullSpeed -> {
                newVelocity = maxV
                newPosition = currentPosition +
                    (currentVelocity + endAccel * maxA * 0.5) * endAccel +
                    maxV * (stepSeconds - endAccel)
            }
            stepSeconds <= endDecel -> {
                val timeLeft = endDecel - stepSeconds
                newVelocity = goalVelocity + timeLeft * maxA
                newPosition = goalPosition - (goalVelocity + timeLeft * maxA * 0.5) * timeLeft
            }
            else -> {
                outState.setTo(goalLocal)
                return
            }
        }

        if (!newPosition.isFinite() || !newVelocity.isFinite()) {
            outState.setTo(currentLocal)
            return
        }
        outState.position = newPosition * direction
        outState.velocity = newVelocity * direction
    }
}
