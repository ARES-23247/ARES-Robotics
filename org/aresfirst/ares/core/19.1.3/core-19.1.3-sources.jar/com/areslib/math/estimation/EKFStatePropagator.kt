package com.areslib.math.estimation

import com.areslib.math.geometry.Matrix3x3
import com.areslib.math.wrapAngle

/**
 * Extended Kalman Filter (EKF) State Transition and Historical Trajectory Re-propagation Engine.
 *
 * Propagates 3-DOF ($x, y, \theta$) pose state error covariance matrices forward using linearized local motion Jacobians ($\mathbf{F}_k$),
 * and executes 100Hz historical trajectory rewind passes whenever a delayed AprilTag vision measurement arrives to correct past states.
 *
 * ### Mathematical Formulation:
 * 1. **Kinematic Motion Model**:
 *    $$\mathbf{f}(x, y, \theta) = \begin{bmatrix} x + \Delta x_{arc} \cos\theta - \Delta y_{arc} \sin\theta \\ y + \Delta x_{arc} \sin\theta + \Delta y_{arc} \cos\theta \\ \text{wrapAngle}(\theta + \Delta\theta) \end{bmatrix}$$
 * 2. **Motion Model Jacobian ($\mathbf{F}_k$)**:
 *    $$\mathbf{F}_k = \begin{bmatrix} 1 & 0 & -\Delta x_{arc} \sin\theta - \Delta y_{arc} \cos\theta \\ 0 & 1 & \Delta x_{arc} \cos\theta - \Delta y_{arc} \sin\theta \\ 0 & 0 & 1 \end{bmatrix}$$
 * 3. **Covariance Propagation ($\mathbf{P}_k$)**:
 *    $$\mathbf{P}_k = \mathbf{F}_k \mathbf{P}_{k-1} \mathbf{F}_k^T + \mathbf{Q}$$
 * 4. **Historical Trajectory Re-propagation**:
 *    Starting from the closest historical frame index $i = k_{\text{vision}}$, applies innovation shift $[\delta x, \delta y, \delta\theta]^T$,
 *    then sequentially integrates stored odometry deltas $(\Delta x_j, \Delta y_j, \Delta\theta_j)$ forward to the current timestamp:
 *    $$\mathbf{P}_j \leftarrow \mathbf{F}_j \mathbf{P}_{j-1} \mathbf{F}_j^T + s_j \mathbf{Q}$$
 *
 * ### Physical Units & Coordinate Conventions:
 * - Position $(x, y, \Delta x, \Delta y)$: Field-centric and robot-centric meters ($m$)
 * - Heading $(\theta, \Delta\theta, \theta_{\text{mid}})$: Radians ($rad$), **CCW-positive** ($0 = +X$, $\frac{\pi}{2} = +Y$)
 * - Time ($t$): Milliseconds ($ms$)
 *
 * ### Zero-GC Guarantee:
 * Uses pre-allocated primitive array buffers (`covarianceArray`) and caller-supplied matrix scratchpads (`scratchCov2`, `scratchHistory`)
 * to eliminate heap allocations during 100Hz trajectory rewind passes.
 *
 * @see PoseEstimator
 * @see VisionMahalanobisFilter
 */
object EKFStatePropagator {

    /**
     * Predicts the historical state at an exact timestamp inside one stored odometry
     * interval. The interval twist and process noise are split by the same fraction.
     */
    fun interpolateHistoryEntry(
        history: HistoryBuffer,
        baseIndex: Int,
        timestampMs: Long,
        baseQ: Matrix3x3,
        output: PoseHistoryEntry
    ): Double {
        val base = history[baseIndex]
        if (baseIndex >= history.size - 1 || timestampMs <= base.timestampMs) {
            output.timestampMs = base.timestampMs
            output.x = base.x
            output.y = base.y
            output.headingRad = base.headingRad
            output.covariance.setTo(base.covariance)
            output.qScale = base.qScale
            output.qHeadingScale = base.effectiveQHeadingScale
            output.deltaXRobot = 0.0
            output.deltaYRobot = 0.0
            output.deltaHeadingRad = 0.0
            output.hasMotion = false
            return 0.0
        }

        val next = history[baseIndex + 1]
        val intervalMs = next.timestampMs - base.timestampMs
        if (intervalMs <= 0L) return 0.0
        val fraction = ((timestampMs - base.timestampMs).toDouble() / intervalMs.toDouble()).coerceIn(0.0, 1.0)

        var twistX = next.deltaXRobot
        var twistY = next.deltaYRobot
        val twistHeading = if (next.hasMotion) next.deltaHeadingRad else wrapAngle(next.headingRad - base.headingRad)
        if (!next.hasMotion) {
            val fieldDx = next.x - base.x
            val fieldDy = next.y - base.y
            val cosBase = kotlin.math.cos(base.headingRad)
            val sinBase = kotlin.math.sin(base.headingRad)
            val arcX = fieldDx * cosBase + fieldDy * sinBase
            val arcY = -fieldDx * sinBase + fieldDy * cosBase
            if (kotlin.math.abs(twistHeading) < 1e-6) {
                twistX = arcX
                twistY = arcY
            } else {
                val s = kotlin.math.sin(twistHeading) / twistHeading
                val c = (1.0 - kotlin.math.cos(twistHeading)) / twistHeading
                val determinant = s * s + c * c
                twistX = (s * arcX + c * arcY) / determinant
                twistY = (-c * arcX + s * arcY) / determinant
            }
        }

        val partialX = twistX * fraction
        val partialY = twistY * fraction
        val partialHeading = twistHeading * fraction
        val s: Double
        val c: Double
        if (kotlin.math.abs(partialHeading) < 1e-6) {
            s = 1.0 - partialHeading * partialHeading / 6.0
            c = partialHeading * 0.5
        } else {
            s = kotlin.math.sin(partialHeading) / partialHeading
            c = (1.0 - kotlin.math.cos(partialHeading)) / partialHeading
        }
        val arcX = s * partialX - c * partialY
        val arcY = c * partialX + s * partialY
        val cosBase = kotlin.math.cos(base.headingRad)
        val sinBase = kotlin.math.sin(base.headingRad)
        val fieldDx = arcX * cosBase - arcY * sinBase
        val fieldDy = arcX * sinBase + arcY * cosBase

        output.timestampMs = timestampMs
        output.x = base.x + fieldDx
        output.y = base.y + fieldDy
        output.headingRad = wrapAngle(base.headingRad + partialHeading)
        output.qScale = next.qScale * fraction
        output.qHeadingScale = next.effectiveQHeadingScale * fraction
        output.deltaXRobot = partialX
        output.deltaYRobot = partialY
        output.deltaHeadingRad = partialHeading
        output.hasMotion = true
        propagateMatrix(
            base.covariance,
            arcX,
            arcY,
            base.headingRad,
            baseQ,
            output.qScale,
            output.effectiveQHeadingScale,
            output.covariance
        )
        return fraction
    }

    private fun propagateMatrix(
        covariance: Matrix3x3,
        arcX: Double,
        arcY: Double,
        heading: Double,
        baseQ: Matrix3x3,
        qScale: Double,
        qHeadingScale: Double,
        output: Matrix3x3
    ) {
        val sinHeading = kotlin.math.sin(heading)
        val cosHeading = kotlin.math.cos(heading)
        val f02 = -arcX * sinHeading - arcY * cosHeading
        val f12 = arcX * cosHeading - arcY * sinHeading
        propagateCovariance(
            covariance.m00, covariance.m01, covariance.m02,
            covariance.m10, covariance.m11, covariance.m12,
            covariance.m20, covariance.m21, covariance.m22,
            f02, f12, baseQ, qScale, qHeadingScale, output
        )
    }

    // Shared scalar kernel for forward, interpolated and replayed covariance.
    // Snapshot inputs before writing output so all matrix scratchpads may alias.
    private fun propagateCovariance(
        p00: Double, p01: Double, p02: Double,
        p10: Double, p11: Double, p12: Double,
        p20: Double, p21: Double, p22: Double,
        f02: Double, f12: Double,
        baseQ: Matrix3x3, qScale: Double, qHeadingScale: Double,
        output: Matrix3x3
    ) {
        val fp00 = p00 + f02 * p20
        val fp01 = p01 + f02 * p21
        val fp02 = p02 + f02 * p22
        val fp10 = p10 + f12 * p20
        val fp11 = p11 + f12 * p21
        val fp12 = p12 + f12 * p22
        val fp20 = p20
        val fp21 = p21
        val fp22 = p22
        // D Q D uses sqrt(translationScale) * sqrt(headingScale). Forming
        // the product before its square root can overflow or erase tiny noise.
        val qCrossScale = kotlin.math.sqrt(qScale.coerceAtLeast(0.0)) *
            kotlin.math.sqrt(qHeadingScale.coerceAtLeast(0.0))
        val m00 = fp00 + f02 * fp02 + baseQ.m00 * qScale
        val m01 = fp01 + f12 * fp02 + baseQ.m01 * qScale
        val m02 = fp02 + baseQ.m02 * qCrossScale
        val m10 = fp10 + f02 * fp12 + baseQ.m10 * qScale
        val m11 = fp11 + f12 * fp12 + baseQ.m11 * qScale
        val m12 = fp12 + baseQ.m12 * qCrossScale
        val m20 = fp20 + f02 * fp22 + baseQ.m20 * qCrossScale
        val m21 = fp21 + f12 * fp22 + baseQ.m21 * qCrossScale
        val m22 = fp22 + baseQ.m22 * qHeadingScale
        output.m00 = m00
        output.m01 = (m01 + m10) * 0.5
        output.m02 = (m02 + m20) * 0.5
        output.m10 = output.m01
        output.m11 = m11
        output.m12 = (m12 + m21) * 0.5
        output.m20 = output.m02
        output.m21 = output.m12
        output.m22 = m22
    }

    /**
     * Propagates a 3x3 state error covariance matrix forward one step using linearized local displacement deltas.
     *
     * @param covarianceArray Flattened 9-element 3x3 covariance matrix array $[P_{00}, P_{01}, \dots, P_{22}]$.
     * @param deltaX Exact local robot-frame arc displacement along X in meters ($m$).
     * @param deltaY Exact local robot-frame arc displacement along Y in meters ($m$).
     * @param theta Heading at the start of the displacement in radians ($rad$).
     * @param qMatrix Process noise covariance matrix $\mathbf{Q}$.
     * @param outCovariance Output [Matrix3x3] scratchpad storing the updated covariance matrix $\mathbf{P}_k$.
     */
    fun propagate(
        covarianceArray: DoubleArray,
        deltaX: Double,
        deltaY: Double,
        theta: Double,
        qMatrix: Matrix3x3,
        outCovariance: Matrix3x3
    ) {
        val sinTheta = kotlin.math.sin(theta)
        val cosTheta = kotlin.math.cos(theta)
        val f02 = -deltaX * sinTheta - deltaY * cosTheta
        val f12 =  deltaX * cosTheta - deltaY * sinTheta

        propagateCovariance(
            covarianceArray[0], covarianceArray[1], covarianceArray[2],
            covarianceArray[3], covarianceArray[4], covarianceArray[5],
            covarianceArray[6], covarianceArray[7], covarianceArray[8],
            f02, f12, qMatrix, 1.0, 1.0, outCovariance
        )
    }

    /**
     * Re-propagates the pose history and covariance buffer from a delayed vision measurement timestamp to the present frame.
     * Non-finite replay results leave the live pose/covariance unchanged. Scratch history may
     * contain partial results after failure and must remain separate from live history.
     *
     * @param state Active EKF pose estimator state snapshot.
     * @param closestIndex Buffer index of the historical pose entry matching the vision observation timestamp.
     * @param baseEntry Historical pose entry prior to vision correction.
     * @param dxX Innovation shift correction along X axis in meters ($m$).
     * @param dxY Innovation shift correction along Y axis in meters ($m$).
     * @param dxZ Innovation shift correction in heading in radians ($rad$).
     * @param updatedCovariance Vision-corrected 3x3 covariance matrix at [closestIndex].
     * @param baseQ Baseline process noise covariance matrix $\mathbf{Q}$.
     * @param scratchHistory Scratchpad history buffer to store re-propagated trajectory entries.
     * @param scratchCov2 Scratchpad 3x3 matrix for incremental covariance propagation.
     */
    fun repropagateHistory(

        state: PoseEstimatorState,
        closestIndex: Int,
        baseEntry: PoseHistoryEntry,
        dxX: Double, dxY: Double, dxZ: Double,
        updatedCovariance: Matrix3x3,
        baseQ: Matrix3x3,
        scratchHistory: HistoryBuffer,
        scratchCov2: Matrix3x3,
        intervalFraction: Double = 0.0
    ) {
        tryRepropagateHistory(state, state.history, closestIndex, baseEntry, dxX, dxY, dxZ,
            updatedCovariance, baseQ, scratchHistory, scratchCov2, intervalFraction)
    }

    /**
     * Replays into caller-owned scratch space and publishes pose/covariance only on success.
     * Source and scratch buffers may alias; original adjacent poses are retained as scalars
     * for legacy entries without recorded motion. Failed scratch results must be discarded.
     */
    internal fun tryRepropagateHistory(
        state: PoseEstimatorState,
        sourceHistory: HistoryBuffer,
        closestIndex: Int,
        baseEntry: PoseHistoryEntry,
        dxX: Double, dxY: Double, dxZ: Double,
        updatedCovariance: Matrix3x3,
        baseQ: Matrix3x3,
        scratchHistory: HistoryBuffer,
        scratchCov2: Matrix3x3,
        intervalFraction: Double = 0.0
    ): Boolean {
        var currentX = baseEntry.x + dxX
        var currentY = baseEntry.y + dxY
        val correctedHeading = baseEntry.headingRad + dxZ
        if (!currentX.isFinite() || !currentY.isFinite() || !correctedHeading.isFinite()) return false
        var currentHeadingRad = wrapAngle(correctedHeading)

        scratchCov2.setTo(updatedCovariance)
        if (!finiteCovariance(scratchCov2)) return false
        var previousRawX = sourceHistory[closestIndex].x
        var previousRawY = sourceHistory[closestIndex].y
        var previousRawHeading = sourceHistory[closestIndex].headingRad
        if (!previousRawX.isFinite() || !previousRawY.isFinite() || !previousRawHeading.isFinite()) return false

        if (intervalFraction <= 0.0) {
            scratchHistory.updateEntryDirect(
                closestIndex,
                baseEntry.timestampMs,
                currentX,
                currentY,
                currentHeadingRad,
                scratchCov2,
                baseEntry.qScale,
                baseEntry.effectiveQHeadingScale
            )
        }

        for (i in (closestIndex + 1) until sourceHistory.size) {
            val currRaw = sourceHistory[i]
            val rawX = currRaw.x
            val rawY = currRaw.y
            val rawHeading = currRaw.headingRad
            if (!rawX.isFinite() || !rawY.isFinite() || !rawHeading.isFinite()) return false
            var twistX = currRaw.deltaXRobot
            var twistY = currRaw.deltaYRobot
            val rawHeadingDifference = rawHeading - previousRawHeading
            var deltaHeading = if (currRaw.hasMotion) currRaw.deltaHeadingRad else {
                if (rawHeadingDifference.isFinite()) wrapAngle(rawHeadingDifference)
                else wrapAngle(wrapAngle(rawHeading) - wrapAngle(previousRawHeading))
            }
            if (!currRaw.hasMotion) {
                val originalFieldDx = rawX - previousRawX
                val originalFieldDy = rawY - previousRawY
                val originalCos = kotlin.math.cos(previousRawHeading)
                val originalSin = kotlin.math.sin(previousRawHeading)
                val robotArcDx = originalFieldDx * originalCos + originalFieldDy * originalSin
                val robotArcDy = -originalFieldDx * originalSin + originalFieldDy * originalCos
                if (kotlin.math.abs(deltaHeading) < 1e-6) {
                    twistX = robotArcDx
                    twistY = robotArcDy
                } else {
                    val s = kotlin.math.sin(deltaHeading) / deltaHeading
                    val c = (1.0 - kotlin.math.cos(deltaHeading)) / deltaHeading
                    val determinant = s * s + c * c
                    twistX = (s * robotArcDx + c * robotArcDy) / determinant
                    twistY = (-c * robotArcDx + s * robotArcDy) / determinant
                }
            }
            if (!twistX.isFinite() || !twistY.isFinite() || !deltaHeading.isFinite()) return false
            val fraction = if (i == closestIndex + 1 && intervalFraction > 0.0) 1.0 - intervalFraction else 1.0
            twistX *= fraction
            twistY *= fraction
            deltaHeading *= fraction
            val expS: Double
            val expC: Double
            if (kotlin.math.abs(deltaHeading) < 1e-6) {
                expS = 1.0 - deltaHeading * deltaHeading / 6.0
                expC = deltaHeading * 0.5
            } else {
                expS = kotlin.math.sin(deltaHeading) / deltaHeading
                expC = (1.0 - kotlin.math.cos(deltaHeading)) / deltaHeading
            }
            val robotArcDx = expS * twistX - expC * twistY
            val robotArcDy = expC * twistX + expS * twistY
            val correctedCos = kotlin.math.cos(currentHeadingRad)
            val correctedSin = kotlin.math.sin(currentHeadingRad)
            val correctedFieldDx = robotArcDx * correctedCos - robotArcDy * correctedSin
            val correctedFieldDy = robotArcDx * correctedSin + robotArcDy * correctedCos

            currentX += correctedFieldDx
            currentY += correctedFieldDy
            val replayHeading = currentHeadingRad + deltaHeading
            if (!currentX.isFinite() || !currentY.isFinite() || !replayHeading.isFinite()) return false
            currentHeadingRad = wrapAngle(replayHeading)

            val scale = currRaw.qScale * fraction
            val headingScale = currRaw.effectiveQHeadingScale * fraction
            if (!scale.isFinite() || scale < 0.0 || !headingScale.isFinite() || headingScale < 0.0) return false
            propagateCovariance(
                scratchCov2.m00, scratchCov2.m01, scratchCov2.m02,
                scratchCov2.m10, scratchCov2.m11, scratchCov2.m12,
                scratchCov2.m20, scratchCov2.m21, scratchCov2.m22,
                -correctedFieldDy, correctedFieldDx, baseQ, scale, headingScale, scratchCov2
            )
            if (!finiteCovariance(scratchCov2)) return false

            scratchHistory.updateEntryDirect(
                i,
                currRaw.timestampMs,
                currentX,
                currentY,
                currentHeadingRad,
                scratchCov2,
                currRaw.qScale,
                currRaw.effectiveQHeadingScale
            )
            previousRawX = rawX
            previousRawY = rawY
            previousRawHeading = rawHeading
        }

        // Apply back to state
        state.estimatedPoseX = currentX
        state.estimatedPoseY = currentY
        state.estimatedPoseHeading = currentHeadingRad

        state.covarianceArray[0] = scratchCov2.m00
        state.covarianceArray[1] = scratchCov2.m01
        state.covarianceArray[2] = scratchCov2.m02
        state.covarianceArray[3] = scratchCov2.m10
        state.covarianceArray[4] = scratchCov2.m11
        state.covarianceArray[5] = scratchCov2.m12
        state.covarianceArray[6] = scratchCov2.m20
        state.covarianceArray[7] = scratchCov2.m21
        state.covarianceArray[8] = scratchCov2.m22
        return true
    }

    private fun finiteCovariance(p: Matrix3x3): Boolean =
        p.m00.isFinite() && p.m01.isFinite() && p.m02.isFinite() &&
            p.m10.isFinite() && p.m11.isFinite() && p.m12.isFinite() &&
            p.m20.isFinite() && p.m21.isFinite() && p.m22.isFinite() &&
            p.m00 >= 0.0 && p.m11 >= 0.0 && p.m22 >= 0.0
}
