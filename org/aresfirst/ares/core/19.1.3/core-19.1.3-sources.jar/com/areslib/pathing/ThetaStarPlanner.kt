package com.areslib.pathing

import com.areslib.math.geometry.Translation2d
import kotlin.math.roundToInt
import com.areslib.pathing.planner.PlannerState

/**
 * Any-angle grid pathfinder implementing the **Theta\*** path planning algorithm.
 *
 * Traditional A* restricts paths to grid lines, generating jagged, artificial zigzag patterns.
 * Theta* bypasses these restrictions by performing a high-speed Bresenham line-of-sight check during
 * neighbor expansion. If a direct line-of-sight exists between a candidate node's parent and a neighbor,
 * the path skips the candidate, linking the neighbor directly to the parent.
 *
 * Parent shortcuts reduce grid-constrained turns; this heuristic search does not promise a globally
 * shortest continuous path. Both shortcuts and neighboring edges honor inflated obstacle corners.
 *
 * ### Physical Units & Guarantees:
 * - **Coordinates:** Field-relative meters ($m$)
 * - **Resolution:** Grid cell spacing ($m/cell$)
 * - **GC Footprint:** Zero heap allocations during path expansion (uses pre-allocated `PlannerState` pools).
 */
object ThetaStarPlanner {

    private val statePool = java.util.concurrent.ConcurrentLinkedQueue<PlannerState>()

    /**
     * Plans a globally safe path from start to end coordinates.
     *
     * @param costmap The grid costmap containing obstacle inflation data.
     * @param start The starting field position in meters ($m$).
     * @param end The target goal position in meters ($m$).
     * @return List of field-relative [Translation2d] waypoint coordinates in meters ($m$).
     */
    fun plan(
        costmap: Costmap,
        start: Translation2d,
        end: Translation2d
    ): List<Translation2d> {
        if (costmap.resolutionMeters <= 0.0 || costmap.resolutionMeters.isInfinite() ||
            !start.x.isFinite() || !start.y.isFinite() || !end.x.isFinite() || !end.y.isFinite()) {
            System.err.println("ThetaStarPlanner: Invalid planning parameters (resolution=${costmap.resolutionMeters}, start=$start, end=$end). Returning empty path.")
            return emptyList()
        }

        val startGridX = (start.x - costmap.origin.x) / costmap.resolutionMeters
        val startGridY = (start.y - costmap.origin.y) / costmap.resolutionMeters
        val endGridX = (end.x - costmap.origin.x) / costmap.resolutionMeters
        val endGridY = (end.y - costmap.origin.y) / costmap.resolutionMeters
        if (!startGridX.isFinite() || !startGridY.isFinite() ||
            !endGridX.isFinite() || !endGridY.isFinite()) return emptyList()
        val startX = startGridX.roundToInt()
        val startY = startGridY.roundToInt()
        val endX = endGridX.roundToInt()
        val endY = endGridY.roundToInt()

        // Out of bounds check
        if (startX !in 0 until costmap.widthCells || startY !in 0 until costmap.heightCells) return emptyList()
        if (endX !in 0 until costmap.widthCells || endY !in 0 until costmap.heightCells) return emptyList()
        if (!endpointTraversable(costmap, startGridX, startGridY, startX, startY) ||
            !endpointTraversable(costmap, endGridX, endGridY, endX, endY)) return emptyList()

        // The same-cell shortcut must not bypass endpoint validity.
        if (startX == endX && startY == endY) return listOf(start, end)

        val capacity = costmap.widthCells * costmap.heightCells
        val state = statePool.poll() ?: PlannerState(10000)
        
        try {
            state.ensureCapacity(capacity)
    
            val openQueue = state.openQueue
    
            val startKey = startY * costmap.widthCells + startX
    
            state.setGCost(startKey, 0.0)
            state.setParent(startKey, startKey)
            
            val startH = heuristic(startX, startY, endX, endY)
            val startFloatBits = startH.toFloat().toBits().toLong() and 0xFFFFFFFFL
            val startHeapVal = (startFloatBits shl 32) or (startKey.toLong() and 0xFFFFFFFFL)
            openQueue.add(startHeapVal)
    
            while (openQueue.isNotEmpty()) {
                val heapVal = openQueue.poll()
                val currKey = (heapVal and 0xFFFFFFFFL).toInt()
    
                if (state.isClosed(currKey)) continue
    
                val currX = currKey % costmap.widthCells
                val currY = currKey / costmap.widthCells
    
                if (currX == endX && currY == endY) {
                    // Path found! Reconstruct waypoints
                    return reconstructPath(currKey, costmap, start, end, state)
                }
    
                state.setClosed(currKey)
    
                // Explore 8-way neighbors
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        if (dx == 0 && dy == 0) continue
    
                        val nx = currX + dx
                        val ny = currY + dy
    
                        // Ensure cell is bounds and traversable
                        if (!costmap.isCellTraversable(nx, ny)) continue
                        // The fallback A* edge must obey the same corner rule as the Theta*
                        // shortcut. Checking only the destination permits diagonal collisions.
                        if (dx != 0 && dy != 0 &&
                            (!costmap.isCellTraversable(currX + dx, currY) ||
                                !costmap.isCellTraversable(currX, currY + dy))) continue
    
                        val nKey = ny * costmap.widthCells + nx
                        if (state.isClosed(nKey)) continue
    
                        updateVertex(currKey, currX, currY, nKey, nx, ny, costmap, endX, endY, state)
                    }
                }
            }
    
            return emptyList() // Return empty if no path found
        } finally {
            statePool.offer(state)
        }
    }

    /** Match closed-cell collision semantics, including points shared by two or four cells. */
    private fun endpointTraversable(costmap: Costmap, x: Double, y: Double, cellX: Int, cellY: Int): Boolean {
        val minX = if (x <= cellX - 0.5) cellX - 1 else cellX
        val maxX = if (x >= cellX + 0.5) cellX + 1 else cellX
        val minY = if (y <= cellY - 0.5) cellY - 1 else cellY
        val maxY = if (y >= cellY + 0.5) cellY + 1 else cellY
        for (cy in minY..maxY) for (cx in minX..maxX) {
            if (!costmap.isCellTraversable(cx, cy)) return false
        }
        return true
    }

    private fun updateVertex(
        currKey: Int,
        currX: Int,
        currY: Int,
        nKey: Int,
        nx: Int,
        ny: Int,
        costmap: Costmap,
        endX: Int,
        endY: Int,
        state: PlannerState
    ) {
        val openQueue = state.openQueue

        var parentKey = state.getParent(currKey)
        if (parentKey == -1) parentKey = currKey

        val parentX = parentKey % costmap.widthCells
        val parentY = parentKey / costmap.widthCells

        // Theta* Line of Sight Check:
        // If there is line of sight from the parent to the neighbor, 
        // bypass the current node to allow any-angle straight pathing.
        val thetaGCost = state.getGCost(parentKey) + distance(parentX, parentY, nx, ny)
        if (thetaGCost < state.getGCost(nKey) && com.areslib.pathing.planner.LineOfSightChecker.lineOfSight(costmap, parentX, parentY, nx, ny)) {
            state.setGCost(nKey, thetaGCost)
            state.setParent(nKey, parentKey)
            
            val f = thetaGCost + heuristic(nx, ny, endX, endY)
            val floatBits = f.toFloat().toBits().toLong() and 0xFFFFFFFFL
            val heapVal = (floatBits shl 32) or (nKey.toLong() and 0xFFFFFFFFL)
            openQueue.add(heapVal)
        } else {
            // Fall back to standard A* update
            val newG = state.getGCost(currKey) + distance(currX, currY, nx, ny)
            if (newG < state.getGCost(nKey)) {
                state.setGCost(nKey, newG)
                state.setParent(nKey, currKey)
                
                val f = newG + heuristic(nx, ny, endX, endY)
                val floatBits = f.toFloat().toBits().toLong() and 0xFFFFFFFFL
                val heapVal = (floatBits shl 32) or (nKey.toLong() and 0xFFFFFFFFL)
                openQueue.add(heapVal)
            }
        }
    }


    private fun distance(x0: Int, y0: Int, x1: Int, y1: Int): Double {
        val dx = (x1 - x0).toDouble()
        val dy = (y1 - y0).toDouble()
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    private fun heuristic(x0: Int, y0: Int, x1: Int, y1: Int): Double {
        // Octile distance heuristic for 8-way diagonal path planning
        val dx = kotlin.math.abs(x1 - x0).toDouble()
        val dy = kotlin.math.abs(y1 - y0).toDouble()
        val min = kotlin.math.min(dx, dy)
        val max = kotlin.math.max(dx, dy)
        return (max - min) + min * 1.414
    }

    private fun reconstructPath(
        endKey: Int,
        costmap: Costmap,
        start: Translation2d,
        end: Translation2d,
        state: PlannerState
    ): List<Translation2d> {
        var currKey = endKey

        var iterations = 0
        val maxIterations = costmap.widthCells * costmap.heightCells
        var pathSize = 0

        while (iterations < maxIterations) {
            iterations++
            val currX = currKey % costmap.widthCells
            val currY = currKey / costmap.widthCells

            val fx = currX * costmap.resolutionMeters + costmap.origin.x
            val fy = currY * costmap.resolutionMeters + costmap.origin.y
            
            if (pathSize * 2 >= state.pathPool.size) {
                val newPool = DoubleArray(state.pathPool.size * 2)
                System.arraycopy(state.pathPool, 0, newPool, 0, state.pathPool.size)
                state.pathPool = newPool
            }
            state.pathPool[pathSize * 2] = fx
            state.pathPool[pathSize * 2 + 1] = fy
            pathSize++

            val parentKey = state.getParent(currKey)
            if (parentKey == currKey || parentKey == -1) break
            currKey = parentKey
        }
        if (iterations >= maxIterations) {
            System.err.println("ThetaStarPlanner: Cyclic parents detected during path reconstruction! Breaking loop safely.")
        }

        // Reverse path in place
        for (i in 0 until pathSize / 2) {
            val opp = pathSize - 1 - i
            val tempX = state.pathPool[i * 2]
            val tempY = state.pathPool[i * 2 + 1]
            state.pathPool[i * 2] = state.pathPool[opp * 2]
            state.pathPool[i * 2 + 1] = state.pathPool[opp * 2 + 1]
            state.pathPool[opp * 2] = tempX
            state.pathPool[opp * 2 + 1] = tempY
        }

        // Keep the segments whose cell-center geometry was checked during search. Moving their
        // endpoints can cut an obstacle corner. Each added connector lies in one convex free cell.
        val startOffset = if (state.pathPool[0] == start.x && state.pathPool[1] == start.y) 0 else 1
        val last = (pathSize - 1) * 2
        val endOffset = if (state.pathPool[last] == end.x && state.pathPool[last + 1] == end.y) 0 else 1
        val resultSize = pathSize + startOffset + endOffset
        return List(resultSize) { i ->
            when {
                startOffset == 1 && i == 0 -> start
                endOffset == 1 && i == resultSize - 1 -> end
                else -> {
                    val index = (i - startOffset) * 2
                    Translation2d(state.pathPool[index], state.pathPool[index + 1])
                }
            }
        }
    }
}
