package com.areslib.telemetry

import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sign

/**
 * Platform-agnostic snapshot of a single gamepad's state.
 * Lives in :core so the logging/replay pipeline can serialize it
 * without depending on any FTC or FRC SDK types.
 */
class GamepadState(
    var leftStickX: Float = 0f,
    var leftStickY: Float = 0f,
    var rightStickX: Float = 0f,
    var rightStickY: Float = 0f,
    var leftTrigger: Float = 0f,
    var rightTrigger: Float = 0f,
    var a: Boolean = false,
    var b: Boolean = false,
    var x: Boolean = false,
    var y: Boolean = false,
    var dpadUp: Boolean = false,
    var dpadDown: Boolean = false,
    var dpadLeft: Boolean = false,
    var dpadRight: Boolean = false,
    var leftBumper: Boolean = false,
    var rightBumper: Boolean = false,
    var leftStickButton: Boolean = false,
    var rightStickButton: Boolean = false,
    var start: Boolean = false,
    var back: Boolean = false,
    var touchpad: Boolean = false,
    var share: Boolean = false,
    var options: Boolean = false,
    var c: Boolean = false,
    var z: Boolean = false,
    var m1: Boolean = false,
    var m2: Boolean = false,
    var m3: Boolean = false,
    var m4: Boolean = false,
    var f1: Boolean = false,
    var f2: Boolean = false,
    var f3: Boolean = false,
    var f4: Boolean = false,
    var f5: Boolean = false,
    var f6: Boolean = false,
    var f7: Boolean = false,
    var f8: Boolean = false,
    var f9: Boolean = false,
    var f10: Boolean = false,
    var f11: Boolean = false,
    var f12: Boolean = false
) {
    fun copyFrom(other: GamepadState) {
        this.leftStickX = other.leftStickX
        this.leftStickY = other.leftStickY
        this.rightStickX = other.rightStickX
        this.rightStickY = other.rightStickY
        this.leftTrigger = other.leftTrigger
        this.rightTrigger = other.rightTrigger
        this.a = other.a
        this.b = other.b
        this.x = other.x
        this.y = other.y
        this.dpadUp = other.dpadUp
        this.dpadDown = other.dpadDown
        this.dpadLeft = other.dpadLeft
        this.dpadRight = other.dpadRight
        this.leftBumper = other.leftBumper
        this.rightBumper = other.rightBumper
        this.leftStickButton = other.leftStickButton
        this.rightStickButton = other.rightStickButton
        this.start = other.start
        this.back = other.back
        this.touchpad = other.touchpad
        this.share = other.share
        this.options = other.options
        this.c = other.c
        this.z = other.z
        this.m1 = other.m1
        this.m2 = other.m2
        this.m3 = other.m3
        this.m4 = other.m4
        this.f1 = other.f1
        this.f2 = other.f2
        this.f3 = other.f3
        this.f4 = other.f4
        this.f5 = other.f5
        this.f6 = other.f6
        this.f7 = other.f7
        this.f8 = other.f8
        this.f9 = other.f9
        this.f10 = other.f10
        this.f11 = other.f11
        this.f12 = other.f12
    }

    fun reset() {
        this.leftStickX = 0f
        this.leftStickY = 0f
        this.rightStickX = 0f
        this.rightStickY = 0f
        this.leftTrigger = 0f
        this.rightTrigger = 0f
        this.a = false
        this.b = false
        this.x = false
        this.y = false
        this.dpadUp = false
        this.dpadDown = false
        this.dpadLeft = false
        this.dpadRight = false
        this.leftBumper = false
        this.rightBumper = false
        this.leftStickButton = false
        this.rightStickButton = false
        this.start = false
        this.back = false
        this.touchpad = false
        this.share = false
        this.options = false
        this.c = false
        this.z = false
        this.m1 = false
        this.m2 = false
        this.m3 = false
        this.m4 = false
        this.f1 = false
        this.f2 = false
        this.f3 = false
        this.f4 = false
        this.f5 = false
        this.f6 = false
        this.f7 = false
        this.f8 = false
        this.f9 = false
        this.f10 = false
        this.f11 = false
        this.f12 = false
    }
}

private const val ANALOG_DEFAULT_FIRST_UPDATE_SECONDS = 0.02
private const val ANALOG_MAX_SLEW_DT_SECONDS = 0.2

internal fun slewIntervalSeconds(timestampMs: Long, previousMs: Long, initialized: Boolean): Double {
    if (!initialized) return ANALOG_DEFAULT_FIRST_UPDATE_SECONDS
    if (timestampMs <= previousMs) return 0.0
    val elapsedMs = timestampMs - previousMs
    // An ordered forward interval that overflows Long is necessarily larger than the cap.
    return if (elapsedMs < 0L || elapsedMs >= 200L) ANALOG_MAX_SLEW_DT_SECONDS else elapsedMs / 1_000.0
}

/** Shapes a 1D axis sample with deadband, exponential curve, inversion, and optional slew limiting. */
internal fun shapeSingleAxisSample(
    selected: Double,
    raw: Double,
    deadbandThreshold: Double,
    curveExponent: Double,
    inverted: Boolean,
    slewRateLimit: Double,
    lastSlewValue: Double,
    timestampMs: Long,
    lastUpdateTimeMs: Long,
    hasSlewTimestamp: Boolean,
    resetSlew: Boolean,
): Double {
    if (!selected.isFinite()) return 0.0
    val afterDeadband = if (abs(raw) < deadbandThreshold) {
        0.0
    } else {
        sign(raw) * (abs(raw) - deadbandThreshold) / (1.0 - deadbandThreshold)
    }
    val afterCurve = if (curveExponent == 1.0) {
        afterDeadband
    } else {
        sign(afterDeadband) * abs(afterDeadband).pow(curveExponent)
    }
    val signedTarget = if (inverted) -afterCurve else afterCurve
    return when {
        resetSlew || slewRateLimit <= 0.0 -> signedTarget
        else -> {
            val dt = slewIntervalSeconds(timestampMs, lastUpdateTimeMs, hasSlewTimestamp)
            val maxDelta = slewRateLimit * dt
            lastSlewValue + (signedTarget - lastSlewValue).coerceIn(-maxDelta, maxDelta)
        }
    }
}

/** Primitive gamepad-axis source. Its [Float] return avoids boxed values in the robot loop. */
fun interface GamepadAxisSource {
    fun read(state: GamepadState): Float
}
