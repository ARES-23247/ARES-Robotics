package com.areslib.reducer

import com.areslib.action.RobotAction
import com.areslib.state.DriveState
import com.areslib.state.DriveMode
import com.areslib.math.estimation.ApplyPoseEstimatorRuntimeResult
import com.areslib.math.estimation.PoseEstimatorSnapshot

/**
 * Object implementation for Drive Reducer.
 *
 * Pure Redux state definition and deterministic reducer transition handler.
 */
object DriveReducer {
    /**
     * Reduces the DriveState slice independently based on drive actions.
     */
    fun reduce(state: DriveState, action: RobotAction): DriveState {
        return when (action) {
            is RobotAction.DriveHardwareUpdate -> reduceDriveHardwareUpdate(state, action, null)
            is RobotAction.PoseUpdate -> reducePoseUpdate(state, action, null)
            is ApplyPoseEstimatorRuntimeResult -> {
                val updatedEstimator = action.estimatorState ?: return state
                state.updateDiagnostics(
                    state.odometryX,
                    state.odometryY,
                    state.odometryHeading,
                    updatedEstimator
                )
            }
            is RobotAction.SetDriveMode -> {
                if (action.mode == DriveMode.X_BRAKE) state.copy(
                    driveMode = action.mode,
                    xVelocityMetersPerSecond = 0.0,
                    yVelocityMetersPerSecond = 0.0,
                    angularVelocityRadiansPerSecond = 0.0,
                    headingLockTargetRadians = null,
                    positionLockX = null,
                    positionLockY = null,
                    isXLock = true,
                ) else state.copy(driveMode = action.mode)
            }
            is RobotAction.SetAlliance -> {
                state.copy(alliance = action.alliance)
            }
            is RobotAction.SetHeadingLockTarget -> {
                state.copy(headingLockTargetRadians = action.targetRadians)
            }
            is RobotAction.SetPositionLockTarget -> {
                state.copy(positionLockX = action.targetX, positionLockY = action.targetY)
            }
            is RobotAction.JoystickDriveIntent -> {
                if (!action.targetXVelocity.isFinite() || !action.targetYVelocity.isFinite() ||
                    !action.targetAngularVelocity.isFinite()) {
                    return state.copy(
                        xVelocityMetersPerSecond = 0.0,
                        yVelocityMetersPerSecond = 0.0,
                        angularVelocityRadiansPerSecond = 0.0,
                        isXLock = false
                    )
                }
                val hasLinearInput = !action.fromPositionHold &&
                    (kotlin.math.abs(action.targetXVelocity) > 0.05 || kotlin.math.abs(action.targetYVelocity) > 0.05)
                val hasAngularInput = !action.fromHeadingHold && kotlin.math.abs(action.targetAngularVelocity) > 0.05
                
                val currentMode = state.driveMode
                var newMode = if (currentMode == DriveMode.X_BRAKE && (hasLinearInput || hasAngularInput)) {
                    DriveMode.TELEOP
                } else {
                    currentMode
                }

                val newTargetHeading = if (hasAngularInput) {
                    null
                } else {
                    state.headingLockTargetRadians
                }

                val newPosLockX = if (hasLinearInput) null else state.positionLockX
                val newPosLockY = if (hasLinearInput) null else state.positionLockY

                if (newMode == DriveMode.POSITION_HOLD && (newPosLockX == null || newPosLockY == null)) {
                    newMode = if (newTargetHeading != null) DriveMode.HEADING_HOLD else DriveMode.TELEOP
                } else if (newMode == DriveMode.HEADING_HOLD && newTargetHeading == null) {
                    newMode = DriveMode.TELEOP
                }

                state.copy(
                    xVelocityMetersPerSecond = action.targetXVelocity,
                    yVelocityMetersPerSecond = action.targetYVelocity,
                    angularVelocityRadiansPerSecond = action.targetAngularVelocity,
                    driveMode = newMode,
                    headingLockTargetRadians = newTargetHeading,
                    positionLockX = newPosLockX,
                    positionLockY = newPosLockY,
                    isFieldCentric = action.isFieldCentric,
                    isXLock = action.isXLock
                )
            }
            else -> state
        }
    }

    internal fun reduceDriveHardwareUpdate(
        state: DriveState,
        action: RobotAction.DriveHardwareUpdate,
        updatedEstimator: PoseEstimatorSnapshot?,
    ): DriveState {
        if (!action.xVelocity.isFinite() || !action.yVelocity.isFinite() ||
            !action.angularVelocity.isFinite() || !action.deltaX.isFinite() ||
            !action.deltaY.isFinite() || !action.deltaHeading.isFinite() ||
            !action.pitchDegrees.isFinite() || !action.rollDegrees.isFinite() ||
            !action.xAccelerationG.isFinite() || !action.yAccelerationG.isFinite() ||
            !action.zAccelerationG.isFinite() ||
            observationDtSeconds(state, action.timestampMs) == null
        ) {
            return if (updatedEstimator != null) {
                state.updateDiagnostics(state.odometryX, state.odometryY, state.odometryHeading, updatedEstimator)
            } else {
                state
            }
        }
        // DriveHardwareUpdate carries a robot-local twist, like the estimator input.
        // Integrate its arc, then rotate using raw odometry's own heading.
        val theta = action.deltaHeading
        val s: Double
        val c: Double
        if (kotlin.math.abs(theta) < 1e-6) {
            s = 1.0 - theta * theta / 6.0
            c = theta * 0.5
        } else {
            s = kotlin.math.sin(theta) / theta
            c = (1.0 - kotlin.math.cos(theta)) / theta
        }
        val arcX = s * action.deltaX - c * action.deltaY
        val arcY = c * action.deltaX + s * action.deltaY
        val cosHeading = kotlin.math.cos(state.odometryHeading)
        val sinHeading = kotlin.math.sin(state.odometryHeading)
        val nextOdomX = state.odometryX + arcX * cosHeading - arcY * sinHeading
        val nextOdomY = state.odometryY + arcX * sinHeading + arcY * cosHeading
        val nextOdomHeading = com.areslib.math.wrapAngle(state.odometryHeading + theta)
        val headingForVel = updatedEstimator?.estimatedPoseHeading ?: nextOdomHeading
        val cosVel = kotlin.math.cos(headingForVel)
        val sinVel = kotlin.math.sin(headingForVel)
        val fieldVelX = action.xVelocity * cosVel - action.yVelocity * sinVel
        val fieldVelY = action.xVelocity * sinVel + action.yVelocity * cosVel
        return if (updatedEstimator == null) {
            state.copy(
                measuredFieldXVelocityMetersPerSecond = fieldVelX,
                measuredFieldYVelocityMetersPerSecond = fieldVelY,
                measuredAngularVelocityRadiansPerSecond = action.angularVelocity,
                measuredMotionValid = true,
                imuMeasurementsValid = true,
                odometryX = nextOdomX,
                odometryY = nextOdomY,
                odometryHeading = nextOdomHeading,
                pitchDegrees = action.pitchDegrees,
                rollDegrees = action.rollDegrees,
                xAccelerationG = action.xAccelerationG,
                yAccelerationG = action.yAccelerationG,
                zAccelerationG = action.zAccelerationG
            )
        } else {
            state.copy(
                measuredFieldXVelocityMetersPerSecond = fieldVelX,
                measuredFieldYVelocityMetersPerSecond = fieldVelY,
                measuredAngularVelocityRadiansPerSecond = action.angularVelocity,
                measuredMotionValid = true,
                imuMeasurementsValid = true,
                odometryX = nextOdomX,
                odometryY = nextOdomY,
                odometryHeading = nextOdomHeading,
                poseEstimator = updatedEstimator,
                pitchDegrees = action.pitchDegrees,
                rollDegrees = action.rollDegrees,
                xAccelerationG = action.xAccelerationG,
                yAccelerationG = action.yAccelerationG,
                zAccelerationG = action.zAccelerationG,
                ekfDriftX = nextOdomX - updatedEstimator.estimatedPoseX,
                ekfDriftY = nextOdomY - updatedEstimator.estimatedPoseY,
                rawOdometryX = nextOdomX,
                rawOdometryY = nextOdomY,
                rawOdometryHeading = nextOdomHeading,
                lastInnovationX = updatedEstimator.lastInnovationX,
                lastInnovationY = updatedEstimator.lastInnovationY,
                lastInnovationTheta = updatedEstimator.lastInnovationTheta
            )
        }
    }

    internal fun reducePoseUpdate(
        state: DriveState,
        action: RobotAction.PoseUpdate,
        updatedEstimator: PoseEstimatorSnapshot?,
    ): DriveState {
        if (!action.xMeters.isFinite() || !action.yMeters.isFinite() ||
            !action.headingRadians.isFinite()
        ) {
            return if (updatedEstimator != null) {
                state.updateDiagnostics(state.odometryX, state.odometryY, state.odometryHeading, updatedEstimator)
            } else {
                state
            }
        }

        val motionMeasurementsValid = action.motionMeasurementsValid &&
            action.xVelocityMetersPerSecond.isFinite() &&
            action.yVelocityMetersPerSecond.isFinite() &&
            action.angularVelocityRadiansPerSecond.isFinite()
        val measuredFieldXVelocity = if (motionMeasurementsValid) action.xVelocityMetersPerSecond else 0.0
        val measuredFieldYVelocity = if (motionMeasurementsValid) action.yVelocityMetersPerSecond else 0.0
        val measuredAngularVelocity = if (motionMeasurementsValid) action.angularVelocityRadiansPerSecond else 0.0
        val imuMeasurementsValid = action.imuMeasurementsValid &&
            action.pitchDegrees.isFinite() && action.rollDegrees.isFinite() &&
            action.pitchVelocityDegPerSec.isFinite() && action.rollVelocityDegPerSec.isFinite() &&
            action.xAccelerationG.isFinite() && action.yAccelerationG.isFinite() &&
            action.zAccelerationG.isFinite()
        val pitchDegrees = if (imuMeasurementsValid) action.pitchDegrees else 0.0
        val rollDegrees = if (imuMeasurementsValid) action.rollDegrees else 0.0
        val xAccelerationG = if (imuMeasurementsValid) action.xAccelerationG else 0.0
        val yAccelerationG = if (imuMeasurementsValid) action.yAccelerationG else 0.0
        val zAccelerationG = if (imuMeasurementsValid) action.zAccelerationG else 0.0

        if (!action.isReset && !action.isExternalEstimate) {
            if ((action.timestampMs <= 0L && !action.motionMeasurementsValid) ||
                observationDtSeconds(state, action.timestampMs) == null
            ) {
                return if (updatedEstimator != null) {
                    state.updateDiagnostics(state.odometryX, state.odometryY, state.odometryHeading, updatedEstimator)
                } else {
                    state
                }
            }
        }

        return if (updatedEstimator == null) {
            state.copy(
                odometryX = action.xMeters,
                odometryY = action.yMeters,
                odometryHeading = action.headingRadians,
                poseEstimateIsExternal = action.isExternalEstimate && !action.isReset,
                measuredFieldXVelocityMetersPerSecond = measuredFieldXVelocity,
                measuredFieldYVelocityMetersPerSecond = measuredFieldYVelocity,
                measuredAngularVelocityRadiansPerSecond = measuredAngularVelocity,
                measuredMotionValid = motionMeasurementsValid,
                pitchDegrees = pitchDegrees,
                rollDegrees = rollDegrees,
                imuMeasurementsValid = imuMeasurementsValid,
                xAccelerationG = xAccelerationG,
                yAccelerationG = yAccelerationG,
                zAccelerationG = zAccelerationG,
                headingLockTargetRadians = if (action.isReset) null else state.headingLockTargetRadians,
                positionLockX = if (action.isReset) null else state.positionLockX,
                positionLockY = if (action.isReset) null else state.positionLockY
            )
        } else {
            state.copy(
                odometryX = action.xMeters,
                odometryY = action.yMeters,
                odometryHeading = action.headingRadians,
                poseEstimator = updatedEstimator,
                poseEstimateIsExternal = action.isExternalEstimate && !action.isReset,
                measuredFieldXVelocityMetersPerSecond = measuredFieldXVelocity,
                measuredFieldYVelocityMetersPerSecond = measuredFieldYVelocity,
                measuredAngularVelocityRadiansPerSecond = measuredAngularVelocity,
                measuredMotionValid = motionMeasurementsValid,
                pitchDegrees = pitchDegrees,
                rollDegrees = rollDegrees,
                imuMeasurementsValid = imuMeasurementsValid,
                xAccelerationG = xAccelerationG,
                yAccelerationG = yAccelerationG,
                zAccelerationG = zAccelerationG,
                headingLockTargetRadians = if (action.isReset) null else state.headingLockTargetRadians,
                positionLockX = if (action.isReset) null else state.positionLockX,
                positionLockY = if (action.isReset) null else state.positionLockY,
                ekfDriftX = action.xMeters - updatedEstimator.estimatedPoseX,
                ekfDriftY = action.yMeters - updatedEstimator.estimatedPoseY,
                rawOdometryX = action.xMeters,
                rawOdometryY = action.yMeters,
                rawOdometryHeading = action.headingRadians,
                lastInnovationX = updatedEstimator.lastInnovationX,
                lastInnovationY = updatedEstimator.lastInnovationY,
                lastInnovationTheta = updatedEstimator.lastInnovationTheta
            )
        }
    }

    /**
     * Derives process-model time from sensor timestamps. Duplicate/out-of-order
     * samples are rejected; long scheduler stalls are bounded so one bad interval
     * cannot explode covariance or gyro-bias integration.
     */
    private fun observationDtSeconds(state: DriveState, timestampMs: Long): Double? {
        val lastTimestampMs = state.poseEstimator.lastObservationTimestampMs
        if (lastTimestampMs < 0L) return 0.02
        val deltaMs = timestampMs - lastTimestampMs
        if (deltaMs <= 0L) return null
        return (deltaMs / 1_000.0).coerceIn(0.001, 0.1)
    }
}
