package com.areslib.state

import com.areslib.math.geometry.Pose3d
import com.areslib.math.geometry.deepCopy
import com.areslib.math.estimation.PoseEstimatorSnapshot
import com.areslib.pathing.Path

/**
 * Holds state for active path tracking, chaining, and detour events.
 * Path references retain shared ownership of their lists and mutable point payloads. Callers
 * must keep those values stable while any state snapshot or follower retains the path.
 */
data class PathState(
    val activePath: Path? = null,
    val currentDistanceMeters: Double = 0.0,
    val isChained: Boolean = false,
    val detourActive: Boolean = false,
    val originalPathBeforeDetour: Path? = null,
    val crossTrackErrorMeters: Double = 0.0,
    val alongTrackErrorMeters: Double = 0.0,
    val headingErrorRadians: Double = 0.0
)

/**
 * Stores the costmap update state.
 */
data class CostmapState(
    val lastUpdateTimestampMs: Long = 0L
)

/**
 * The root immutable state tree for the entire robot.
 */
data class RobotState(
    val drive: DriveState = DriveState(),
    val superstructure: SuperstructureState = SuperstructureState(),
    val vision: VisionState = VisionState(),
    val costmap: CostmapState = CostmapState(),
    val pathState: PathState = PathState(),
    val routineState: RoutineLifecycleState = RoutineLifecycleState(),
    val tuning: TuningState = TuningState(),
    val timestampMs: Long = 0L
)

/**
 * DriveMode declaration.
 *
 * @param args Standard arguments (if applicable).
 * @return Corresponding output value or Unit.
 */
enum class DriveMode {
    TELEOP,
    HEADING_HOLD,
    POSITION_HOLD,
    X_BRAKE
}

/**
 * Class implementation for Drive State.
 *
 * Pure Redux state definition and deterministic reducer transition handler.
 */
data class DriveState(
    val xVelocityMetersPerSecond: Double = 0.0,
    val yVelocityMetersPerSecond: Double = 0.0,
    val angularVelocityRadiansPerSecond: Double = 0.0,
    /** Measured field-relative X velocity, distinct from the commanded drive intent above. */
    val measuredFieldXVelocityMetersPerSecond: Double = 0.0,
    /** Measured field-relative Y velocity, distinct from the commanded drive intent above. */
    val measuredFieldYVelocityMetersPerSecond: Double = 0.0,
    val measuredAngularVelocityRadiansPerSecond: Double = 0.0,
    /** True only when all measured chassis velocity components were fresh and finite. */
    val measuredMotionValid: Boolean = false,
    val odometryX: Double = 0.0,
    val odometryY: Double = 0.0,
    val odometryHeading: Double = 0.0,
    val poseEstimator: PoseEstimatorSnapshot = PoseEstimatorSnapshot(),
    /** True when [poseEstimator] mirrors an upstream authoritative estimator (for example CTRE). */
    val poseEstimateIsExternal: Boolean = false,
    val pitchDegrees: Double = 0.0,
    val rollDegrees: Double = 0.0,
    /** True only when the inertial sample associated with this drive observation was fresh and finite. */
    val imuMeasurementsValid: Boolean = false,
    val xAccelerationG: Double = 0.0,
    val yAccelerationG: Double = 0.0,
    val zAccelerationG: Double = 0.0,
    val driveMode: DriveMode = DriveMode.TELEOP,
    val headingLockTargetRadians: Double? = null,
    val positionLockX: Double? = null,
    val positionLockY: Double? = null,
    val isFieldCentric: Boolean = true,
    val isXLock: Boolean = false,
    val alliance: Alliance = Alliance.BLUE,
    // EKF diagnostics not already carried by the immutable estimator snapshot:
    val ekfDriftX: Double = 0.0,
    val ekfDriftY: Double = 0.0,
    val lastInnovationX: Double = 0.0,
    val lastInnovationY: Double = 0.0,
    val lastInnovationTheta: Double = 0.0,
    val rawOdometryX: Double = 0.0,
    val rawOdometryY: Double = 0.0,
    val rawOdometryHeading: Double = 0.0
) {
    /**
     * updateDiagnostics declaration.
     *
     * @param args Standard arguments (if applicable).
     * @return Corresponding output value or Unit.
     */
    fun updateDiagnostics(odomX: Double, odomY: Double, odomHeading: Double, updatedEstimator: PoseEstimatorSnapshot): DriveState {
        return this.copy(
            poseEstimator = updatedEstimator,
            ekfDriftX = odomX - updatedEstimator.estimatedPoseX,
            ekfDriftY = odomY - updatedEstimator.estimatedPoseY,
            rawOdometryX = odomX,
            rawOdometryY = odomY,
            rawOdometryHeading = odomHeading,
            lastInnovationX = updatedEstimator.lastInnovationX,
            lastInnovationY = updatedEstimator.lastInnovationY,
            lastInnovationTheta = updatedEstimator.lastInnovationTheta
        )
    }
}

/**
 * Marker interface for custom subsystem states.
 */
interface SubsystemState

/**
 * SuperstructureState declaration.
 *
 * @param args Standard arguments (if applicable).
 * @return Corresponding output value or Unit.
 */
data class SuperstructureState(
    /** Maps indicator light hardware names to their target servo positions (0.0 to 1.0). */
    val indicatorLights: Map<String, Double> = emptyMap(),
    /** Maps goBILDA Prism RGB LED Driver hardware names to their target pulse width in microseconds (500–2500µs). */
    val prismDrivers: Map<String, Int> = emptyMap(),
    /** Independently addressable GUI/DSL-defined mechanism states. */
    val subsystems: Map<String, SubsystemState> = emptyMap(),
    // Custom extensible container for season/robot-specific states
    val custom: Any? = null
)

/**
 * A single AprilTag fiducial detection from the vision subsystem.
 *
 * @property timestampMs Capture timestamp in milliseconds from [com.areslib.util.RobotClock].
 * @property targetPose The tag's 3D pose in the robot's coordinate frame (meters, radians).
 * @property tagId The detected AprilTag's numeric fiducial ID.
 * @property ambiguity PnP pose ambiguity score (0.0 = perfect, >0.2 = unreliable).
 * @property tagCount Number of AprilTags contributing to this single camera pose solve.
 * @property robotPoseTargetSpace The robot's 3D pose expressed in **target-space** coordinates.
 *
 *   ## Target-Space Coordinate Frame
 *   Origin is at the center of the AprilTag face:
 *   - **X+**: to the right of the tag (when facing the tag)
 *   - **Y+**: upward from the tag (vertical axis)
 *   - **Z+**: outward from the tag face (toward the observer/camera) — this is the depth/distance axis
 *
 *   ## Translation Access
 *   - `robotPoseTargetSpace.x` → lateral offset (positive = robot is right of tag center)
 *   - `robotPoseTargetSpace.y` → vertical offset (positive downward in Limelight target space)
 *   - `robotPoseTargetSpace.z` → distance from tag face (always positive, in meters)
 *
 *   ## ⚠️ CRITICAL: Rotation Axis Mapping (Limelight → Rotation3d)
 *   The Limelight SDK reports roll/pitch/yaw in FTC conventions, but target-space
 *   has a **different vertical axis** (Y-up) than FTC field space (Z-up). The raw
 *   Limelight euler angles are passed directly into `Rotation3d(roll, pitch, yaw)`
 *   WITHOUT a coordinate transform (see [FtcLimelightIO]). This creates a mismatch:
 *
 *   | Physical Rotation          | Limelight SDK Call | Rotation3d Property | Euler Axis |
 *   |----------------------------|--------------------|---------------------|------------|
 *   | Robot tilting sideways     | `getRoll()`        | `rotation.x`        | X (roll)   |
 *   | **Robot heading (yaw)**    | `getPitch()`       | **`rotation.y`**    | Y (pitch)  |
 *   | Robot tilting forward/back | `getYaw()`         | `rotation.z`        | Z (yaw)    |
 *
 *   **The robot's heading rotation relative to the tag (left/right turning) is in
 *   `rotation.y`, NOT `rotation.z`.** This is because in target-space the vertical
 *   axis is Y, so heading rotation is around Y. The Limelight SDK's `getPitch()`
 *   returns this value, which maps to `Rotation3d.y`.
 *
 *   **Sign convention:** Negate `rotation.y` for standard CCW-positive heading:
 *   ```kotlin
 *   val robotYaw = -robotPoseTargetSpace.rotation.y  // heading relative to tag
 *   ```
 *
 *   This pose is the raw output from Limelight's `robotPoseTargetSpace` pipeline result.
 *   It is used by the alignment controller to compute translational and rotational errors
 *   for driving the robot square to the tag at a desired standoff distance.
 */
/**
 * Class implementation for Vision Measurement.
 *
 * Object-pooled data structure for zero-GC vision pipeline measurements.
 */
enum class VisionSolverType {
    UNKNOWN,
    MEGATAG1,
    MEGATAG2,
    PHOTONVISION,
    VISION_PORTAL
}

data class VisionMeasurement(
    var timestampMs: Long = 0L,
    /** Capture timestamp in the source's monotonic microsecond clock; zero when unavailable. */
    var captureTimestampMicros: Long = 0L,
    var targetPose: Pose3d = Pose3d(),
    var tagId: Int = -1,
    var ambiguity: Double = 0.0,
    /** False when the platform API does not expose solve ambiguity. */
    var ambiguityAvailable: Boolean = true,
    var robotPoseTargetSpace: Pose3d = Pose3d(),
    /** Number of tags used to solve this single field-pose observation. */
    var tagCount: Int = 1,
    /** Multi-tag geometry and image-quality metrics; negative means unavailable. */
    var tagSpanMeters: Double = -1.0,
    var averageTagDistanceMeters: Double = -1.0,
    var averageTagAreaPercent: Double = -1.0,
    /** Stable camera/source identifier used for per-source frame de-duplication. */
    var sourceId: String = "",
    /** Monotonic camera frame identifier. Zero means that the source cannot provide one. */
    var frameId: Long = 0L,
    /** Pose solver that produced this observation. */
    var solverType: VisionSolverType = VisionSolverType.UNKNOWN,
    /** Total capture and processing latency reported by the source. */
    var latencyMs: Double = 0.0,
    /** Optional observation-specific standard deviations. Non-positive/NaN means unspecified. */
    var stdDevXMeters: Double = 0.0,
    var stdDevYMeters: Double = 0.0,
    var stdDevHeadingRadians: Double = 0.0,
    /** Independent MegaTag1 field pose reserved for stationary full-pose recovery. */
    var recoveryPose: Pose3d = Pose3d(),
    var hasRecoveryPose: Boolean = false,
    /** Ambiguity associated specifically with [recoveryPose]. */
    var recoveryAmbiguity: Double = 0.0,
    var recoveryAmbiguityAvailable: Boolean = false
) {
    /** Snapshots this pooled/mutable measurement for immutable Redux or replay ownership. */
    fun ownedCopy(): VisionMeasurement = VisionMeasurement(
        timestampMs = timestampMs,
        captureTimestampMicros = captureTimestampMicros,
        targetPose = targetPose.deepCopy(),
        recoveryPose = recoveryPose.deepCopy(),
        hasRecoveryPose = hasRecoveryPose,
        recoveryAmbiguity = recoveryAmbiguity,
        recoveryAmbiguityAvailable = recoveryAmbiguityAvailable,
        tagId = tagId,
        ambiguity = ambiguity,
        ambiguityAvailable = ambiguityAvailable,
        robotPoseTargetSpace = robotPoseTargetSpace.deepCopy(),
        tagCount = tagCount,
        tagSpanMeters = tagSpanMeters,
        averageTagDistanceMeters = averageTagDistanceMeters,
        averageTagAreaPercent = averageTagAreaPercent,
        sourceId = sourceId,
        frameId = frameId,
        solverType = solverType,
        latencyMs = latencyMs,
        stdDevXMeters = stdDevXMeters,
        stdDevYMeters = stdDevYMeters,
        stdDevHeadingRadians = stdDevHeadingRadians
    )
}

/**
 * Class implementation for Vision State.
 *
 * Pure Redux state definition and deterministic reducer transition handler.
 */
data class VisionState(
    val lastTargetTimestampMs: Long = 0L,
    val targetX: Double = 0.0,
    val targetY: Double = 0.0,
    val hasTarget: Boolean = false,
    val measurements: List<VisionMeasurementSnapshot> = emptyList(),
    val filterConfig: com.areslib.hardware.vision.VisionFilterConfig = com.areslib.hardware.vision.VisionFilterConfig.ftcDefaults(),
    // EKF diagnostics:
    val lastMeasurementAccepted: Boolean = false,
    val lastRejectionReason: String? = null,
    val covarianceBeforeUpdate: Matrix3x3Snapshot? = null,
    val covarianceAfterUpdate: Matrix3x3Snapshot? = null,
    val measurementCount: Int = 0,
    val rejectionCount: Int = 0,
    /** Last computed local NIS in the current vision batch; DOF zero means unavailable. */
    val lastNis: Double = 0.0,
    val lastNisDegreesOfFreedom: Int = 0,
    val lastNisTimestampMs: Long = 0L,
    val lastNisSourceId: String = "",
    val lastNisFrameId: Long = 0L,
    val lastNisTagId: Int = -1,
    val lastNisSolverType: VisionSolverType = VisionSolverType.UNKNOWN,
    val lastNisAccepted: Boolean = false,
    /** Original input index requested by the current vision batch; -1 means unavailable. */
    val diagnosticMeasurementIndex: Int = -1,
    /** Result for [diagnosticMeasurementIndex], independent of the last batch or NIS outcome. */
    val diagnosticMeasurementAccepted: Boolean = false,
    val diagnosticMeasurementRejectionReason: String? = null,
    /** Latest moving-target observations; never field landmarks or EKF inputs. */
    val clusterTargets: List<com.areslib.hardware.vision.ClusterTargetSnapshot> = emptyList()
)

/**
 * Alliance declaration.
 *
 * @param args Standard arguments (if applicable).
 * @return Corresponding output value or Unit.
 */
enum class Alliance {
    RED, BLUE
}
