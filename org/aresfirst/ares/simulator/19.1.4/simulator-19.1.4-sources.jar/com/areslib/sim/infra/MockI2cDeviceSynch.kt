package com.areslib.sim.infra

import com.qualcomm.robotcore.hardware.I2cAddr
import com.qualcomm.robotcore.hardware.I2cDeviceSynch

/**
 * Class implementation for Mock I2c Device Synch.
 *
 * Robotics framework control component.
 */
class MockI2cDeviceSynch : I2cDeviceSynch {
    override var i2cAddress: I2cAddr = I2cAddr.create7bit(0x00)
    
    val registers = ByteArray(256)
    
    var onWrite: ((register: Int, data: ByteArray) -> Unit)? = null
    var onRead: ((register: Int, length: Int) -> Unit)? = null

    override fun read8(ireg: Int): Byte {
        onRead?.invoke(ireg, 1)
        return registers.getOrElse(ireg) { 0 }
    }

    override fun read(ireg: Int, length: Int): ByteArray {
        onRead?.invoke(ireg, length)
        val data = ByteArray(length)
        for (i in 0 until length) {
            val regIndex = ireg + i
            data[i] = registers.getOrElse(regIndex) { 0 }
        }
        return data
    }

    override fun write(ireg: Int, data: ByteArray) {
        for (i in data.indices) {
            val regIndex = ireg + i
            if (regIndex in 0..255) {
                registers[regIndex] = data[i]
            }
        }
        onWrite?.invoke(ireg, data)
    }

    override var readWindow: I2cDeviceSynch.ReadWindow = 
        I2cDeviceSynch.ReadWindow(0, 256, I2cDeviceSynch.ReadMode.REPEAT)
}
