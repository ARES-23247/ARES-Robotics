package com.areslib.project

import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import com.areslib.util.sha256Hex

const val ARES_PROJECT_METADATA_SCHEMA_VERSION: Int = 5

enum class AresLeague { FTC, FRC, XRP }

/** Which source is authoritative when Studio and project-owned Kotlin coexist. */
enum class AresProjectAuthoringModel {
    /** Canonical `.ares` documents own the robot; Kotlin runtime and tests are generated. */
    GUI_OWNED,

    /** Team-owned Kotlin owns robot behavior; Studio consumes explicit registration metadata. */
    CODE_FIRST,

    /** `.ares` owns drivetrain/routines while registered team Kotlin owns selected mechanisms. */
    HYBRID,
}

/** Human and competition identity stored with the stable project ID in `.ares/project.json`. */
data class AresProjectIdentityDocument(
    val teamId: String,
    val seasonId: String,
    val robotId: String,
    val displayName: String,
)

/** FTC hub-command transport selected by the canonical project document. */
enum class AresFtcHubCommandTransport {
    /** Use only the supported FTC SDK command path. Recommended for new teams and first bring-up. */
    STANDARD_SDK,

    /** Use ARES' experimental direct REV Hub motor-write path, with SDK fallback on every failure. */
    ARES_PHOTON,
}

/** FTC-only runtime choices that materially change robot-process behavior. */
data class AresFtcRuntimeOptionsDocument(
    val hubCommandTransport: AresFtcHubCommandTransport = AresFtcHubCommandTransport.STANDARD_SDK,
    /** Start the bounded Control-Hub-to-Limelight HTTP proxy while the robot facade is alive. */
    val limelightProxyEnabled: Boolean = false,
)

/** The two SparkFun controllers supported by the ARES XRP runtime. */
enum class AresXrpControllerModel(
    val firmwareBoardId: String,
    val motorChannels: IntRange,
    val servoChannels: IntRange,
) {
    SPARKFUN_XRP_RP2350("xrp-2350", 1..4, 1..4),
    SPARKFUN_XRP_BETA_RP2040("xrp-beta", 1..4, 1..2),
}

/** XRP-only runtime choices that configure controller identity, wireless, and safety behavior. */
data class AresXrpRuntimeOptionsDocument(
    val controllerModel: AresXrpControllerModel,
    val wifiMode: String = "AP",
    val ssid: String = "ARES-XRP-AUTO",
    /** Dedicated ARES XRP Link port. NT4 remains on 5810 for FTC/FRC robots and simulators. */
    val port: Int = 5811,
    val deadmanTimeoutMs: Int = 200,
    val brownoutThresholdVolts: Double = 4.3,
)

/** Platform-specific runtime choices. Unsupported platform sections are rejected, not ignored. */
data class AresRuntimeOptionsDocument(
    val ftc: AresFtcRuntimeOptionsDocument? = null,
    val xrp: AresXrpRuntimeOptionsDocument? = null,
)

/** Coordinate frame used by authored routine poses. Headings are CCW-positive in every frame. */
enum class AresCoordinateConvention {
    /** Origin at field center; FTC alliance transforms rotate 180 degrees around that origin. */
    CENTER_ORIGIN_CCW,

    /** Origin at the blue-alliance field corner; FRC alliance transforms reflect field X. */
    BLUE_CORNER_ORIGIN_CCW,
}

/**
 * Canonical project geometry shared by the editor, generator, simulator, and robot preflight.
 *
 * Keeping these values in `.ares/project.json` prevents two laptops from validating the same
 * routine with different machine-local workspace settings.
 */
data class AresProjectMetadataDocument(
    val schemaVersion: Int = ARES_PROJECT_METADATA_SCHEMA_VERSION,
    val projectId: String,
    val identity: AresProjectIdentityDocument,
    val league: AresLeague,
    val coordinateConvention: AresCoordinateConvention,
    val robotLengthMeters: Double,
    val robotWidthMeters: Double,
    val fieldLengthMeters: Double,
    val fieldWidthMeters: Double,
    val authoringModel: AresProjectAuthoringModel = AresProjectAuthoringModel.GUI_OWNED,
    val runtimeOptions: AresRuntimeOptionsDocument = AresRuntimeOptionsDocument(),
)

/** Returns the required FTC runtime policy from a current FTC project document. */
fun AresProjectMetadataDocument.requireFtcRuntimeOptions(): AresFtcRuntimeOptionsDocument {
    require(league == AresLeague.FTC) { "FTC runtime options are only valid for FTC projects" }
    return requireNotNull(runtimeOptions.ftc) { "FTC projects must declare runtimeOptions.ftc" }
}

/** Returns the required XRP runtime policy from a current XRP project document. */
fun AresProjectMetadataDocument.requireXrpRuntimeOptions(): AresXrpRuntimeOptionsDocument {
    require(league == AresLeague.XRP) { "XRP runtime options are only valid for XRP projects" }
    return requireNotNull(runtimeOptions.xrp) { "XRP projects must declare runtimeOptions.xrp" }
}

fun validateAresProjectMetadata(document: AresProjectMetadataDocument): List<String> = buildList {
    if (document.schemaVersion != ARES_PROJECT_METADATA_SCHEMA_VERSION) {
        add("Unsupported project metadata schema ${document.schemaVersion}")
    }
    if (!document.projectId.matches(Regex("[A-Za-z][A-Za-z0-9._-]{0,63}"))) {
        add("Project ID must be a stable key")
    }
    if (!document.identity.teamId.matches(Regex("[A-Za-z0-9][A-Za-z0-9._-]{0,31}"))) {
        add("Team ID must be a stable team key")
    }
    if (!document.identity.seasonId.matches(Regex("[A-Za-z0-9][A-Za-z0-9._-]{0,31}"))) {
        add("Season ID must be a stable season key")
    }
    if (!document.identity.robotId.matches(Regex("[A-Za-z][A-Za-z0-9._-]{0,63}"))) {
        add("Robot ID must be a stable key")
    }
    if (document.identity.displayName.isBlank() || document.identity.displayName.length > 80) {
        add("Robot display name must contain 1 to 80 characters")
    }
    val dimensions = listOf(
        "robotLengthMeters" to document.robotLengthMeters,
        "robotWidthMeters" to document.robotWidthMeters,
        "fieldLengthMeters" to document.fieldLengthMeters,
        "fieldWidthMeters" to document.fieldWidthMeters,
    )
    dimensions.forEach { (name, value) ->
        if (!value.isFinite() || value <= 0.0) add("$name must be finite and positive")
    }
    if (document.robotLengthMeters > document.fieldLengthMeters ||
        document.robotWidthMeters > document.fieldWidthMeters
    ) {
        add("Robot footprint must fit inside the field")
    }
    when (document.league) {
        AresLeague.FTC -> if (document.coordinateConvention != AresCoordinateConvention.CENTER_ORIGIN_CCW) {
            add("FTC projects must use CENTER_ORIGIN_CCW")
        }
        AresLeague.FRC -> if (document.coordinateConvention != AresCoordinateConvention.BLUE_CORNER_ORIGIN_CCW) {
            add("FRC projects must use BLUE_CORNER_ORIGIN_CCW")
        }
        AresLeague.XRP -> if (document.coordinateConvention != AresCoordinateConvention.CENTER_ORIGIN_CCW) {
            add("XRP projects must use CENTER_ORIGIN_CCW")
        }
    }
    if (document.league == AresLeague.FRC && document.runtimeOptions.ftc != null) {
        add("FRC projects cannot declare FTC runtime options")
    }
    if (document.league != AresLeague.XRP && document.runtimeOptions.xrp != null) {
        add("Only XRP projects may declare XRP runtime options")
    }
    if (document.league == AresLeague.FTC && document.runtimeOptions.ftc == null) {
        add("FTC projects must declare runtimeOptions.ftc")
    }
    if (document.league == AresLeague.XRP && document.runtimeOptions.ftc != null) {
        add("XRP projects cannot declare FTC runtime options")
    }
    if (document.league == AresLeague.XRP) {
        val options = document.runtimeOptions.xrp
        if (options == null) {
            add("XRP projects must declare runtimeOptions.xrp")
        } else {
            if (options.wifiMode !in setOf("AP", "STATION")) {
                add("XRP wifiMode must be AP or STATION")
            }
            if (options.ssid.isBlank() || options.ssid.length > 32) {
                add("XRP SSID must contain 1 to 32 characters")
            }
            if (options.port !in 1024..65535 || options.port == 5810) {
                add("XRP Link port must be between 1024 and 65535 and must not use the NT4 port 5810")
            }
            if (options.deadmanTimeoutMs !in 100..1_000) {
                add("XRP deadman timeout must be between 100 and 1000 milliseconds")
            }
            if (!options.brownoutThresholdVolts.isFinite() || options.brownoutThresholdVolts !in 3.0..6.0) {
                add("XRP brownout threshold must be finite and between 3.0 and 6.0 volts")
            }
        }
    }
}

object AresProjectMetadataCodec {
    private val gson = GsonBuilder().setPrettyPrinting().create()

    fun encode(document: AresProjectMetadataDocument): String {
        val normalized = normalize(document)
        requireValid(normalized)
        return gson.toJson(normalized)
    }

    fun decode(json: String): AresProjectMetadataDocument {
        val root = try {
            gson.fromJson(json, JsonObject::class.java)
        } catch (error: Exception) {
            throw IllegalArgumentException("Project metadata is not valid JSON: ${error.message}", error)
        }
        val schemaVersion = root.requiredInt("schemaVersion")
        require(schemaVersion == ARES_PROJECT_METADATA_SCHEMA_VERSION) {
            "Unsupported project metadata schema $schemaVersion; create or export a current ARES project"
        }
        val document = decodeCurrent(root)
        requireValid(document)
        return document
    }

    fun contentHash(document: AresProjectMetadataDocument): String = sha256Hex(encode(document))

    private fun requireValid(document: AresProjectMetadataDocument) {
        val issues = validateAresProjectMetadata(document)
        require(issues.isEmpty()) { issues.joinToString("; ") }
    }

    private fun normalize(document: AresProjectMetadataDocument): AresProjectMetadataDocument =
        document.copy(schemaVersion = ARES_PROJECT_METADATA_SCHEMA_VERSION)

    private fun decodeCurrent(root: JsonObject): AresProjectMetadataDocument {
        val league = root.requiredEnum<AresLeague>("league")
        val identity = root.requiredObject("identity").let { value ->
            AresProjectIdentityDocument(
                teamId = value.requiredString("teamId"),
                seasonId = value.requiredString("seasonId"),
                robotId = value.requiredString("robotId"),
                displayName = value.requiredString("displayName"),
            )
        }
        val runtime = root.requiredObject("runtimeOptions")
        val ftc = runtime.get("ftc")?.takeUnless { it.isJsonNull }?.let { element ->
            require(element.isJsonObject) { "Project metadata field 'runtimeOptions.ftc' must be an object or null" }
            val value = element.asJsonObject
            AresFtcRuntimeOptionsDocument(
                hubCommandTransport = value.requiredEnum("hubCommandTransport"),
                limelightProxyEnabled = value.requiredBoolean("limelightProxyEnabled"),
            )
        }
        val xrp = runtime.get("xrp")?.takeUnless { it.isJsonNull }?.let { element ->
            require(element.isJsonObject) { "Project metadata field 'runtimeOptions.xrp' must be an object or null" }
            val value = element.asJsonObject
            AresXrpRuntimeOptionsDocument(
                controllerModel = value.requiredEnum("controllerModel"),
                wifiMode = value.requiredString("wifiMode"),
                ssid = value.requiredString("ssid"),
                port = value.requiredInt("port"),
                deadmanTimeoutMs = value.requiredInt("deadmanTimeoutMs"),
                brownoutThresholdVolts = value.requiredDouble("brownoutThresholdVolts"),
            )
        }
        require(league != AresLeague.FTC || ftc != null) {
            "FTC project metadata must declare 'runtimeOptions.ftc'"
        }
        require(league != AresLeague.XRP || xrp != null) {
            "XRP project metadata must declare 'runtimeOptions.xrp'"
        }
        val runtimeOptions = AresRuntimeOptionsDocument(ftc = ftc, xrp = xrp)
        return normalize(
            AresProjectMetadataDocument(
                schemaVersion = ARES_PROJECT_METADATA_SCHEMA_VERSION,
                projectId = root.requiredString("projectId"),
                identity = identity,
                league = league,
                coordinateConvention = root.requiredEnum("coordinateConvention"),
                robotLengthMeters = root.requiredDouble("robotLengthMeters"),
                robotWidthMeters = root.requiredDouble("robotWidthMeters"),
                fieldLengthMeters = root.requiredDouble("fieldLengthMeters"),
                fieldWidthMeters = root.requiredDouble("fieldWidthMeters"),
                authoringModel = root.requiredEnum("authoringModel"),
                runtimeOptions = runtimeOptions,
            ),
        )
    }
}

private fun JsonObject.requiredElement(name: String) = get(name)?.takeUnless { it.isJsonNull }
    ?: throw IllegalArgumentException("Project metadata is missing required field '$name'")

private fun JsonObject.requiredObject(name: String): JsonObject = requiredElement(name).let { element ->
    require(element.isJsonObject) { "Project metadata field '$name' must be an object" }
    element.asJsonObject
}

private fun JsonObject.requiredPrimitive(name: String): JsonPrimitive = requiredElement(name).let { element ->
    require(element.isJsonPrimitive) { "Project metadata field '$name' must be a primitive value" }
    element.asJsonPrimitive
}

private fun JsonObject.requiredString(name: String): String = requiredPrimitive(name).let { value ->
    require(value.isString) { "Project metadata field '$name' must be a string" }
    value.asString
}

private fun JsonObject.requiredBoolean(name: String): Boolean = requiredPrimitive(name).let { value ->
    require(value.isBoolean) { "Project metadata field '$name' must be a boolean" }
    value.asBoolean
}

private fun JsonObject.requiredInt(name: String): Int = requiredPrimitive(name).let { value ->
    require(value.isNumber) { "Project metadata field '$name' must be an integer" }
    runCatching { value.asBigDecimal.intValueExact() }
        .getOrElse { throw IllegalArgumentException("Project metadata field '$name' must be an integer", it) }
}

private fun JsonObject.requiredDouble(name: String): Double = requiredPrimitive(name).let { value ->
    require(value.isNumber) { "Project metadata field '$name' must be a number" }
    val result = value.asDouble
    require(result.isFinite()) { "Project metadata field '$name' must be a finite number" }
    result
}

private inline fun <reified T : Enum<T>> JsonObject.requiredEnum(name: String): T {
    val raw = requiredString(name)
    return enumValues<T>().firstOrNull { it.name == raw }
        ?: throw IllegalArgumentException("Project metadata field '$name' has unsupported value '$raw'")
}
