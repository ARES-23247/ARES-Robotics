package com.areslib.ftc.dsl

import com.areslib.state.aprilTagPoseMap
import com.areslib.ftc.FtcBaseRobot
import com.areslib.ftc.update
import com.areslib.telemetry.AresGamepad
import com.areslib.telemetry.GamepadState
import com.areslib.telemetry.RobotStatusTracker
import com.areslib.telemetry.SimInputBridge
import com.areslib.util.PoseStorage
import com.qualcomm.robotcore.eventloop.opmode.OpMode
import org.firstinspires.ftc.robotcore.external.Telemetry
import kotlin.math.abs

/** Prevents lifecycle declarations from accidentally resolving against the wrong nested receiver. */
@DslMarker
annotation class AresOpModeDsl

/**
 * Stable receiver exposed to every TeleOp lifecycle block.
 *
 * [driver] maps Driver Station gamepad 1 and [operator] maps gamepad 2. The same receiver instance is
 * reused throughout the OpMode; callbacks should keep their own small state in the surrounding class
 * or DSL block when needed.
 */
@AresOpModeDsl
class FtcTeleOpContext<R> internal constructor(
    val robot: R,
    val driver: AresGamepad,
    val operator: AresGamepad,
    val telemetry: Telemetry
)

/**
 * Declarative FTC TeleOp definition with lifecycle names that match when each block executes.
 *
 * A typical mode defines [controls] and/or [everyLoop], or opts into generated project drive
 * (`allowGeneratedDrive = true` in `AresTeleOpBase`). [setup], [duringInit], [onStart], and
 * [onStop] are optional. Registering the same phase twice is a configuration error instead of
 * silently discarding the first block.
 *
 * ### Lifecycle Order
 * 1. [setup] — once during `init()`, immediately after the robot is constructed.
 * 2. [controls] — once during `init()`, after [setup], to register [driver] and [operator] bindings.
 * 3. [duringInit] — every `init_loop()` tick while waiting for Start (keep non-blocking).
 * 4. [onStart] — once during `start()`, after autonomous pose restoration and input priming.
 * 5. [everyLoop] — every active `loop()` tick after gamepad bindings are evaluated and before `updateRobot`.
 * 6. [onStop] — once during `stop()`, before generated controls are cancelled and the robot is closed.
 *
 * ### Example
 * ```kotlin
 * @TeleOp(name = "Competition TeleOp", group = "Competition")
 * class CompetitionTeleOp : AresTeleOpBase() {
 *     override fun define() = teleOp {
 *         val moveStick = driver.leftStick.withDeadband(0.05).withExponentialCurve(2.0)
 *         val turnStick = driver.rightStick.withDeadband(0.05).withExponentialCurve(2.0)
 *
 *         controls {
 *             driver.a.onPress("Collect") { robot.intake.collect() }
 *             driver.rightTrigger.onPress(threshold = 0.5, description = "Score") { robot.shooter.score() }
 *         }
 *
 *         everyLoop {
 *             robot.driveFieldCentric(
 *                 vx = -moveStick.shapedY * 2.5,
 *                 vy = -moveStick.shapedX * 2.5,
 *                 omega = -turnStick.shapedX * Math.PI,
 *             )
 *         }
 *
 *         onStop {
 *             telemetry.addData("Status", "Stopped cleanly")
 *         }
 *     }
 * }
 * ```
 */
@AresOpModeDsl
class FtcTeleOpBuilder<R> {
    internal var setupBlock: (FtcTeleOpContext<R>.() -> Unit)? = null
        private set
    internal var controlsBlock: (FtcTeleOpContext<R>.() -> Unit)? = null
        private set
    internal var duringInitBlock: (FtcTeleOpContext<R>.() -> Unit)? = null
        private set
    internal var onStartBlock: (FtcTeleOpContext<R>.() -> Unit)? = null
        private set
    internal var everyLoopBlock: (FtcTeleOpContext<R>.() -> Unit)? = null
        private set
    internal var onStopBlock: (FtcTeleOpContext<R>.() -> Unit)? = null
        private set
    internal var hasExternalDriveOrControls: Boolean = false

    /** Runs once immediately after the robot is built. Configure initial robot state here. */
    fun setup(block: FtcTeleOpContext<R>.() -> Unit) {
        check(setupBlock == null) { "TeleOp setup { } may only be declared once" }
        setupBlock = block
    }

    /** Runs once after [setup]. Bind driver and operator buttons here. */
    fun controls(block: FtcTeleOpContext<R>.() -> Unit) {
        check(controlsBlock == null) { "TeleOp controls { } may only be declared once" }
        controlsBlock = block
    }

    /** Runs repeatedly while the Driver Station shows INIT. Keep this non-blocking. */
    fun duringInit(block: FtcTeleOpContext<R>.() -> Unit) {
        check(duringInitBlock == null) { "TeleOp duringInit { } may only be declared once" }
        duringInitBlock = block
    }

    /** Runs exactly once after pose restoration and immediately before the active loop. */
    fun onStart(block: FtcTeleOpContext<R>.() -> Unit) {
        check(onStartBlock == null) { "TeleOp onStart { } may only be declared once" }
        onStartBlock = block
    }

    /** Runs once per active robot loop. Optional when [controls] or generated project drive is active. */
    fun everyLoop(block: FtcTeleOpContext<R>.() -> Unit) {
        check(everyLoopBlock == null) { "TeleOp everyLoop { } may only be declared once" }
        everyLoopBlock = block
    }

    /** Runs once when the OpMode stops, before generated controls are cancelled and hardware is closed. */
    fun onStop(block: FtcTeleOpContext<R>.() -> Unit) {
        check(onStopBlock == null) { "TeleOp onStop { } may only be declared once" }
        onStopBlock = block
    }

    internal fun validate() {
        require(everyLoopBlock != null || controlsBlock != null || hasExternalDriveOrControls) {
            "TeleOp definition is missing everyLoop { ... } or controls { ... }; add the robot's periodic or button behavior there"
        }
    }
}

/** Creates and validates a student-facing TeleOp definition. */
fun <R> teleOp(block: FtcTeleOpBuilder<R>.() -> Unit): FtcTeleOpBuilder<R> =
    FtcTeleOpBuilder<R>().apply(block).also { it.validate() }

/**
 * Generic lifecycle runner for declarative FTC TeleOps.
 *
 * Hardware is refreshed during INIT and the active phase. Pose restoration is typed through
 * [getBaseRobot], so wrappers never require reflection. Cleanup always disables Photon after the
 * team robot has been closed.
 */
abstract class FtcTeleOpBase<R> : OpMode() {
    abstract fun define(): FtcTeleOpBuilder<R>
    abstract fun buildRobot(): R
    abstract fun getBaseRobot(robot: R): FtcBaseRobot?
    abstract fun updateRobot(robot: R, g1: GamepadState, g2: GamepadState)
    abstract fun closeRobot(robot: R)

    /**
     * Runs generated project controls only during an active TeleOp frame, after hand-authored
     * callbacks and before [updateRobot] writes outputs. Season shells may override this hook;
     * INIT never invokes it, so controller input cannot arm a mechanism before Start.
     */
    open fun updateProjectControls(robot: R, g1: GamepadState, g2: GamepadState) = Unit

    /** Cancels generated bindings/tasks before the robot is closed. */
    open fun cancelProjectControls(robot: R) = Unit

    private var definition: FtcTeleOpBuilder<R>? = null
    private var robot: R? = null
    private var context: FtcTeleOpContext<R>? = null
    private val driver = AresGamepad()
    private val operator = AresGamepad()
    private val g1State = GamepadState()
    private val g2State = GamepadState()
    private var closed = false

    /** Builds the robot and evaluates the one-time DSL setup phases. */
    final override fun init() {
        val builtDefinition = define().also { it.validate() }
        com.areslib.math.estimation.PoseEstimator.activeTags =
            com.areslib.state.RobotFieldManager.activeConfig.aprilTagPoseMap()
        val builtRobot = buildRobot()
        val builtContext = FtcTeleOpContext(builtRobot, driver, operator, telemetry)
        definition = builtDefinition
        robot = builtRobot
        context = builtContext

        builtDefinition.setupBlock?.invoke(builtContext)
        labelDefaultDriverControls(driver)
        builtDefinition.controlsBlock?.invoke(builtContext)
    }

    /** Refreshes hardware and the optional INIT callback once per SDK init frame. */
    final override fun init_loop() {
        val activeRobot = robot ?: return
        refreshGamepadStates()
        driver.prime(g1State)
        operator.prime(g2State)
        updateRobot(activeRobot, g1State, g2State)
        context?.let { definition?.duringInitBlock?.invoke(it) }
    }

    /** Restores autonomous pose and invokes the one-time start callback. */
    final override fun start() {
        val activeRobot = robot ?: return
        RobotStatusTracker.activeOpMode = "TeleOp"
        restoreStartingPose(getBaseRobot(activeRobot))
        refreshGamepadStates()
        driver.prime(g1State)
        operator.prime(g2State)
        context?.let { definition?.onStartBlock?.invoke(it) }
    }

    /** Executes one bounded driver-control frame. */
    final override fun loop() {
        val activeRobot = robot ?: return
        val activeContext = context ?: return
        refreshGamepadStates()
        applySimulationDriveInput(g1State)
        driver.update(g1State)
        operator.update(g2State)
        definition?.everyLoopBlock?.invoke(activeContext)
        updateProjectControls(activeRobot, g1State, g2State)
        updateRobot(activeRobot, g1State, g2State)
    }

    /** Closes the robot and optional Photon transport exactly once. */
    final override fun stop() {
        if (closed) return
        closed = true
        val activeRobot = robot
        val activeContext = context
        try {
            try {
                if (activeContext != null) {
                    definition?.onStopBlock?.invoke(activeContext)
                }
            } finally {
                if (activeRobot != null) {
                    try {
                        cancelProjectControls(activeRobot)
                    } finally {
                        closeRobot(activeRobot)
                    }
                }
            }
        } finally {
            robot = null
            context = null
            try {
                com.areslib.ftc.photon.AresPhotonCore.disable()
            } catch (_: Exception) {
                // Robot shutdown must continue when the optional Photon layer was never enabled.
            }
        }
    }

    private fun refreshGamepadStates() {
        g1State.update(gamepad1)
        g2State.update(gamepad2)
    }

    private fun restoreStartingPose(baseRobot: FtcBaseRobot?) {
        if (baseRobot == null) return
        val savedPose = PoseStorage.snapshot
        val state: com.areslib.state.RobotState? = baseRobot.store.state
        val rawAlliance: com.areslib.state.Alliance? = state?.drive?.alliance
        val fallbackAlliance = when {
            rawAlliance === com.areslib.state.Alliance.BLUE -> com.areslib.state.Alliance.BLUE
            else -> com.areslib.state.Alliance.RED
        }
        val restoredAlliance = allianceForTeleOpRestore(savedPose, fallbackAlliance)
        baseRobot.store.dispatch(com.areslib.action.RobotAction.SetAlliance(restoredAlliance))
        if (savedPose != null) {
            baseRobot.resetPose(savedPose.pose)
        } else {
            baseRobot.resetPoseForAlliance()
        }
    }

    private fun applySimulationDriveInput(g1State: GamepadState) {
        val commandFrame = SimInputBridge.currentFrame()
        val webVx = commandFrame.vx
        val webVy = commandFrame.vy
        val webOmega = commandFrame.omega
        if (!webVx.isFinite() || !webVy.isFinite() || !webOmega.isFinite()) return
        if (abs(webVx) <= 0.01 && abs(webVy) <= 0.01 && abs(webOmega) <= 0.01) return

        if (abs(g1State.leftStickY) < 0.05f) {
            g1State.leftStickY = (-webVx / 4.0).coerceIn(-1.0, 1.0).toFloat()
        }
        if (abs(g1State.leftStickX) < 0.05f) {
            g1State.leftStickX = (-webVy / 4.0).coerceIn(-1.0, 1.0).toFloat()
        }
        if (abs(g1State.rightStickX) < 0.05f) {
            g1State.rightStickX = (-webOmega / 2.0).coerceIn(-1.0, 1.0).toFloat()
        }
    }

    private fun labelDefaultDriverControls(driver: AresGamepad) {
        driver.leftStick.label("Field-centric translation")
        driver.rightStickX.label("Robot rotation")
    }
}

/** Invalid pose storage must not leak an alliance retained by an older autonomous run. */
internal fun allianceForTeleOpRestore(
    savedPose: PoseStorage.Snapshot?,
    fallbackAlliance: com.areslib.state.Alliance = com.areslib.state.Alliance.RED,
): com.areslib.state.Alliance = savedPose?.alliance ?: fallbackAlliance
