package com.areslib.ftc.hardware

import com.qualcomm.robotcore.hardware.DcMotorEx
import com.qualcomm.robotcore.hardware.DcMotor
import com.qualcomm.robotcore.hardware.DcMotorSimple
import com.qualcomm.robotcore.hardware.Servo
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit
import kotlin.math.abs

/**
 * Non-blocking caching decorator for [DcMotorEx] hardware objects to eliminate redundant REV I2C writes.
 *
 * Tracks the last commanded power and writes only when:
 * 1. The target changes to zero, guaranteeing one hard-stop command.
 * 2. The absolute command delta is at least [epsilon] ($|u-u_{last}| \ge \epsilon$).
 *
 * ### Performance & Bus Optimization:
 * This reduces REV Lynx command traffic and allocates no objects in the setter. Before the first
 * command, the getter delegates to hardware; after the first command it returns only the cached
 * value and never performs a hardware read until configuration invalidates the cache.
 * Power is clamped to [-1, 1]; non-finite commands neutralize. Configuration changes
 * invalidate the cache so the next explicit command reaches the device. A failed write forces
 * the next command to reach hardware, even when returning to the last accepted value.
 *
 * @param delegate Underlying FTC SDK [DcMotorEx] hardware instance.
 * @param epsilon Power change threshold tolerance $[0.0, 1.0]$ (default 0.02).
 *
 * @see DcMotorEx
 */
class CachedDcMotorEx(
    private val delegate: DcMotorEx,
    private val epsilon: Double = 0.02
) : DcMotorEx by delegate {

    init { require(epsilon in 0.0..1.0) { "Power cache epsilon must be within [0, 1]" } }

    private var hasPowerCommand = false
    private var powerWriteUncertain = false
    private var lastPower = 0.0

    override fun getPower(): Double = if (hasPowerCommand) lastPower else delegate.power
    override fun setPower(value: Double) {
        val command = if (value.isFinite()) value.coerceIn(-1.0, 1.0) else 0.0
        if (!hasPowerCommand || powerWriteUncertain || (command != lastPower &&
            (command == 0.0 || abs(command - lastPower) >= epsilon))) {
            powerWriteUncertain = true
            delegate.power = command
            powerWriteUncertain = false
            lastPower = command
            hasPowerCommand = true
        }
    }

    override fun getMode(): DcMotor.RunMode = delegate.mode
    override fun setMode(value: DcMotor.RunMode) {
        hasPowerCommand = false
        delegate.mode = value
    }

    override fun getDirection(): DcMotorSimple.Direction = delegate.direction
    override fun setDirection(value: DcMotorSimple.Direction) {
        hasPowerCommand = false
        delegate.direction = value
    }

    override fun setVelocity(angularRate: Double) {
        hasPowerCommand = false
        powerWriteUncertain = true
        delegate.velocity = angularRate
        powerWriteUncertain = false
    }

    override fun setVelocity(angularRate: Double, unit: AngleUnit) {
        hasPowerCommand = false
        powerWriteUncertain = true
        delegate.setVelocity(angularRate, unit)
        powerWriteUncertain = false
    }

    @Suppress("DEPRECATION")
    override fun setPowerFloat() {
        hasPowerCommand = false
        powerWriteUncertain = true
        delegate.setPowerFloat()
        powerWriteUncertain = false
    }

    override fun setMotorDisable() {
        hasPowerCommand = false
        powerWriteUncertain = true
        delegate.setMotorDisable()
        powerWriteUncertain = false
    }

    override fun setMotorEnable() {
        hasPowerCommand = false
        powerWriteUncertain = true
        delegate.setMotorEnable()
        powerWriteUncertain = false
    }

    override fun resetDeviceConfigurationForOpMode() {
        hasPowerCommand = false
        powerWriteUncertain = false
        delegate.resetDeviceConfigurationForOpMode()
    }
}

/**
 * Non-blocking caching decorator for [Servo] hardware objects to eliminate redundant REV I2C writes.
 *
 * Tracks the last commanded position setting and only delegates calls to the physical servo driver if the
 * position delta exceeds tolerance threshold [epsilon] ($|p - p_{last}| \ge \epsilon$).
 *
 * ### Performance & Bus Optimization:
 * Prevents redundant servo PWM updates and allocates no objects in the setter. Before the first
 * command, the getter delegates to hardware; afterward it returns only the cached command. The
 * position is clamped to [0, 1]. Non-finite positions are rejected because a servo has
 * no universal neutral position. Direction/range changes and device resets invalidate the command
 * cache before delegation, including when configuration throws after applying a change. Failed writes force
 * the next command through while getters retain the last accepted value without polling hardware.
 *
 * @param delegate Underlying FTC SDK [Servo] hardware instance.
 * @param epsilon Servo position threshold tolerance $[0.0, 1.0]$ (default 0.005).
 *
 * @see Servo
 */
class CachedServo(
    private val delegate: Servo,
    private val epsilon: Double = 0.005
) : Servo by delegate {

    init { require(epsilon in 0.0..1.0) { "Position cache epsilon must be within [0, 1]" } }

    private var hasPositionCommand = false
    private var positionWriteUncertain = false
    private var lastPosition = 0.0

    override fun getPosition(): Double = if (hasPositionCommand) lastPosition else delegate.position
    override fun setPosition(value: Double) {
        require(value.isFinite()) { "Servo position must be finite" }
        val command = value.coerceIn(0.0, 1.0)
        if (!hasPositionCommand || positionWriteUncertain ||
            (command != lastPosition && abs(command - lastPosition) >= epsilon)) {
            positionWriteUncertain = true
            delegate.position = command
            positionWriteUncertain = false
            lastPosition = command
            hasPositionCommand = true
        }
    }

    override fun resetDeviceConfigurationForOpMode() {
        hasPositionCommand = false
        delegate.resetDeviceConfigurationForOpMode()
    }

    override fun getDirection(): Servo.Direction = delegate.direction
    override fun setDirection(value: Servo.Direction) {
        hasPositionCommand = false
        delegate.direction = value
    }

    override fun scaleRange(min: Double, max: Double) {
        hasPositionCommand = false
        delegate.scaleRange(min, max)
    }
}

