package com.areslib.codegen

/**
 * Canonical Kotlin source literals shared by the mechanical code generators.
 *
 * Keeping these rules in one place prevents otherwise-identical generators from disagreeing about
 * string-template escaping, negative zero, control characters, or generated type-name casing.
 */
internal fun String.kotlinPascalCase(): String = split(KOTLIN_WORD_SEPARATOR)
    .filter(String::isNotEmpty)
    .joinToString("") { it.replaceFirstChar(Char::uppercaseChar) }

internal fun String.kotlinStringLiteral(): String = buildString(length + 2) {
    append('"')
    this@kotlinStringLiteral.forEach { character ->
        when (character) {
            '\\' -> append("\\\\")
            '"' -> append("\\\"")
            '$' -> append("\\$")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            '\b' -> append("\\b")
            else -> if (
                character.code < 0x20 ||
                character.code in 0xD800..0xDFFF ||
                character == '\u2028' ||
                character == '\u2029'
            ) {
                append("\\u${character.code.toString(16).padStart(4, '0')}")
            } else {
                append(character)
            }
        }
    }
    append('"')
}

internal fun Double.kotlinDoubleLiteral(): String {
    require(isFinite()) { "Cannot render a non-finite Kotlin number" }
    if (this == -0.0) return "0.0"
    val rendered = toString()
    return if (rendered.contains('.') || rendered.contains('e', ignoreCase = true)) rendered else "$rendered.0"
}

internal fun String.isKotlinIdentifier(): Boolean =
    matches(KOTLIN_IDENTIFIER) && any { it != '_' } && this !in KOTLIN_KEYWORDS

internal fun String.isKotlinPackageName(): Boolean = split('.').all { it.isKotlinIdentifier() }

internal fun String.isKotlinQualifiedName(): Boolean = contains('.') && isKotlinPackageName()

private val KOTLIN_WORD_SEPARATOR = Regex("[^A-Za-z0-9]+")
private val KOTLIN_IDENTIFIER = Regex("[A-Za-z_][A-Za-z0-9_]*")

internal val KOTLIN_KEYWORDS = setOf(
    "as", "break", "class", "continue", "do", "else", "false", "for", "fun", "if", "in",
    "interface", "is", "null", "object", "package", "return", "super", "this", "throw", "true",
    "try", "typealias", "typeof", "val", "var", "when", "while", "by", "catch", "constructor",
    "delegate", "dynamic", "field", "file", "finally", "get", "import", "init", "param", "property",
    "receiver", "set", "setparam", "where", "actual", "abstract", "annotation", "companion", "const",
    "crossinline", "data", "enum", "expect", "external", "final", "infix", "inline", "inner", "internal",
    "lateinit", "noinline", "open", "operator", "out", "override", "private", "protected", "public",
    "reified", "sealed", "suspend", "tailrec", "vararg",
)

// Transitional domain names used throughout the subsystem renderer. They deliberately delegate to
// the canonical implementation so the large renderer can be split without a noisy all-at-once
// textual rewrite.
internal fun String.pascalCase(): String = kotlinPascalCase()
internal fun String.quoted(): String = kotlinStringLiteral()
internal fun Double.kotlinDouble(): String = kotlinDoubleLiteral()
