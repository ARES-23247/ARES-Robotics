package org.firstinspires.ftc.teamcode.opmodes.robot

import com.areslib.ftc.FtcMecanumRobot

internal fun formatLowBatteryVoltage(voltage: Double): String {
    val tenths = kotlin.math.round(voltage * 10.0).toLong()
    val intPart = tenths / 10
    val fracPart = kotlin.math.abs(tenths % 10)
    return "<font color='red'><b>$intPart.${fracPart}V (LOW)</b></font>"
}

/**
 * Bridges season convenience calls to low-rate Redux-backed telemetry.
 * Driver Station text is capped and rate-limited to avoid dominating the control loop.
 */
class AresTelemetryHelper(private val base: FtcMecanumRobot) {
    private var lastTelemetryUpdateMs: Long = 0L
    private var hasTelemetryUpdate = false

    /** Stores one custom Driver Station value, truncated to 150 display characters. */
    fun addTelemetry(key: String, value: Any) {
        val truncated = value.toString().take(150)
        base.telemetryManager.customDriverStationText[key] = truncated
    }

    /** Publishes the low-rate pose, battery, and power-budget summary. */
    fun updateTelemetry() {
        val now = com.areslib.util.RobotClock.currentTimeMillis()
        val elapsed = now - lastTelemetryUpdateMs
        if (hasTelemetryUpdate && now >= lastTelemetryUpdateMs && elapsed >= 0L && elapsed < TELEMETRY_PERIOD_MS) return
        lastTelemetryUpdateMs = now
        hasTelemetryUpdate = true

        val drive = base.store.state.drive
        val estimate = drive.poseEstimator
        addTelemetry("Alliance", drive.alliance.name)
        addTelemetry("EKF Pose X", estimate.estimatedPoseX)
        addTelemetry("EKF Pose Y", estimate.estimatedPoseY)
        addTelemetry("EKF Pose Deg", Math.toDegrees(estimate.estimatedPoseHeading))

        val voltage = base.powerManager.batteryVoltage
        val batteryText = when {
            !voltage.isFinite() || voltage <= 0.0 -> "<font color='red'><b>INVALID</b></font>"
            voltage < 11.5 -> formatLowBatteryVoltage(voltage)
            else -> voltage
        }
        addTelemetry("Battery V", batteryText)

        addTelemetry("Power Scale", base.powerManager.powerScale)
    }

    companion object {
        private const val TELEMETRY_PERIOD_MS = 100L
    }
}
