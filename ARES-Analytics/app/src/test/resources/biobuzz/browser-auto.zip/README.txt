BIOBUZZ auto. Import this ZIP in ARES Studio's auto editor with a BIOBUZZ RobotBuilder project open.
